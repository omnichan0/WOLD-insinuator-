/**
 * OMEGA-8D SYSTEM BRIDGE
 * Connects all backend systems to the game frontend.
 * Auto-detects if running on Replit (zero-config AI) or standalone.
 */

// Auto-detect environment
const IS_REPLIT = window.location.hostname.includes('repl.co') || 
                   window.location.hostname.includes('replit') ||
                   localStorage.getItem('omega8d_replit_mode') === 'true';

// If on Replit, the game server proxies AI automatically at /api/ai/
// No admin config needed — zero config
const LOCAL_AI = IS_REPLIT ? {
  endpoint: '/api/ai/completion',
  health: '/api/ai/health',
  config: '/api/ai/config',
  auto: true,
} : null;

const OMEGA = {
  // Backend endpoints (Base44 cloud functions for wallet/admin/map)
  API: {
    MAP: 'https://miro-1f2f091d.base44.app/functions/omega8dMapApi',
    WALLET: 'https://miro-1f2f091d.base44.app/functions/omega8dWallet',
    AI: 'https://miro-1f2f091d.base44.app/functions/omega8dAI',
    ADMIN: 'https://miro-1f2f091d.base44.app/functions/omega8dAdmin',
  },

  // Local AI (Replit WhiteRabbit) — auto-wired, zero config
  localAI: LOCAL_AI,
  aiOnline: false,
  aiModel: 'whiterabbit',

  // Player state
  player: {
    playerId: localStorage.getItem('omega8d_player_id') || '',
    wallet: null,
    profile: null,
    aiSubscription: null,
    adminToken: localStorage.getItem('omega8d_admin_token') || '',
  },

  // === API CALL HELPER ===
  async call(apiName, action, data = {}) {
    try {
      const res = await fetch(this.API[apiName], {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action, data }),
      });
      return await res.json();
    } catch (e) {
      console.error(`API ${apiName}/${action} failed:`, e);
      return { success: false, error: e.message };
    }
  },

  // === LOCAL AI CALL (WhiteRabbit on Replit — zero config) ===
  async callLocalAI(messages, maxTokens = 1000) {
    if (!this.localAI) {
      // Fall back to Base44 backend
      return this.call('AI', 'aiAutoplayDecision', { 
        playerId: this.player.playerId, 
        gameState: messages,
      });
    }
    try {
      const res = await fetch(this.localAI.endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messages, max_tokens: maxTokens }),
      });
      return await res.json();
    } catch (e) {
      console.error('Local AI failed:', e);
      return { success: false, error: e.message };
    }
  },

  // === AUTO-CHECK AI HEALTH ON STARTUP ===
  async checkLocalAI() {
    if (!this.localAI) { this.aiOnline = false; return false; }
    try {
      const res = await fetch(this.localAI.health, { signal: AbortSignal.timeout(5000) });
      const data = await res.json();
      this.aiOnline = data.status === 'online';
      this.aiModel = data.model || 'whiterabbit';
      console.log('[OMEGA-8D] Local AI:', this.aiOnline ? 'ONLINE' : 'OFFLINE', 'Model:', this.aiModel);
      return this.aiOnline;
    } catch (e) {
      this.aiOnline = false;
      console.log('[OMEGA-8D] Local AI offline — falling back to Base44 backend');
      return false;
    }
  },

  // === PLAYER INITIALIZATION ===
  async initPlayer(playerId) {
    this.player.playerId = playerId;
    localStorage.setItem('omega8d_player_id', playerId);

    // Check local AI first (zero-config on Replit)
    await this.checkLocalAI();

    // Load wallet
    const wallet = await this.call('WALLET', 'getWallet', { playerId });
    if (!wallet.success) {
      await this.call('WALLET', 'getDepositInfo', { playerId });
    }
    this.player.wallet = wallet.success ? wallet.wallet : { balanceUSD: 0 };

    // Load player profile
    const profile = await this.call('MAP', 'getPlayer', { playerId });
    this.player.profile = profile.success ? profile.player : null;

    return {
      wallet: this.player.wallet,
      profile: this.player.profile,
      aiOnline: this.aiOnline,
      aiModel: this.aiModel,
    };
  },

  // === WALLET ACTIONS ===
  wallet: {
    async getBalance() { return OMEGA.call('WALLET', 'getWallet', { playerId: OMEGA.player.playerId }); },
    async getDepositInfo() { return OMEGA.call('WALLET', 'getDepositInfo', { playerId: OMEGA.player.playerId }); },
    async confirmDeposit(txHash) { return OMEGA.call('WALLET', 'confirmDeposit', { txHash, playerId: OMEGA.player.playerId }); },
    async convert(gameCurrency, amountUSD) { return OMEGA.call('WALLET', 'convertToGame', { playerId: OMEGA.player.playerId, gameCurrency, amountUSD }); },
    async spend(amountUSD, item) { return OMEGA.call('WALLET', 'spendBalance', { playerId: OMEGA.player.playerId, amountUSD, item }); },
    async buyWarp(tier) { return OMEGA.call('WALLET', 'buyWarpBack', { playerId: OMEGA.player.playerId, warpTier: tier }); },
    async getTransactions() { return OMEGA.call('WALLET', 'getTransactions', { playerId: OMEGA.player.playerId }); },
    async registerWallet(addr) { return OMEGA.call('WALLET', 'registerWalletAddress', { playerId: OMEGA.player.playerId, walletAddress: addr }); },
  },

  // === MAP API ACTIONS ===
  map: {
    async createZone(name, lat, lng, country) { return OMEGA.call('MAP', 'createZone', { zoneName: name, lat, lng, country, createdBy: OMEGA.player.playerId }); },
    async modifyZone(zoneId, modType, coords, radius) { return OMEGA.call('MAP', 'modifyZone', { zoneId, type: modType, coords, radius, createdBy: OMEGA.player.playerId }); },
    async getPlayer(pid) { return OMEGA.call('MAP', 'getPlayer', { playerId: pid || OMEGA.player.playerId }); },
    async updateProfile(updates) { return OMEGA.call('MAP', 'updatePlayer', { playerId: OMEGA.player.playerId, ...updates }); },
    async createMatch(zoneId, teams, winCondition) { return OMEGA.call('MAP', 'createMatch', { zoneId, teams, winCondition }); },
    async getModifications(zoneId) { return OMEGA.call('MAP', 'getModifications', { zoneId }); },
    async createRecruitment(banner) { return OMEGA.call('MAP', 'createRecruitment', banner); },
  },

  // === AI ACTIONS (auto-routes: local WhiteRabbit → Base44 backend) ===
  ai: {
    async autoplayDecision(gameState) {
      // Try local AI first (WhiteRabbit on Replit)
      if (OMEGA.aiOnline) {
        const messages = [
          { role: 'system', content: 'You are a tactical AI for OMEGA-8D military shooter. Output only JSON.' },
          { role: 'user', content: `Game state: ${JSON.stringify(gameState).substring(0, 2000)}\nRespond: {"action":"move|shoot|reload|ability|banish|strike|heal|defend|warp","target":"enemy or null","reasoning":"brief","urgency":"low|medium|high|critical"}` },
        ];
        const r = await OMEGA.callLocalAI(messages);
        if (r.success) {
          try { return { success: true, decision: JSON.parse(r.response.replace(/```json|```/g, '').trim()), source: 'whiterabbit' }; }
          catch (e) { return { success: true, decision: { action: 'defend' }, source: 'whiterabbit' }; }
        }
      }
      // Fall back to Base44 backend
      return OMEGA.call('AI', 'aiAutoplayDecision', { playerId: OMEGA.player.playerId, gameState });
    },

    async voiceCommand(command, gameState) {
      if (OMEGA.aiOnline) {
        const messages = [
          { role: 'system', content: 'You are OMEGA-8D voice command processor. Output ONLY JSON.' },
          { role: 'user', content: `Command: "${command}"\nGame state: ${JSON.stringify(gameState || {}).substring(0, 500)}\nRespond: {"action":"...","params":{...}}` },
        ];
        const r = await OMEGA.callLocalAI(messages);
        if (r.success) {
          try { return { success: true, command: JSON.parse(r.response.replace(/```json|```/g, '').trim()), source: 'whiterabbit' }; }
          catch (e) { return { success: true, command: { action: 'unknown' }, source: 'whiterabbit' }; }
        }
      }
      return OMEGA.call('AI', 'processVoiceCommand', { playerId: OMEGA.player.playerId, command, gameState });
    },

    async updateBehavior(stats) { return OMEGA.call('AI', 'updateAIBehavior', { playerId: OMEGA.player.playerId, stats }); },
    async activateSubscription() { return OMEGA.call('AI', 'activateAISubscription', { playerId: OMEGA.player.playerId }); },
    async checkSubscription() { return OMEGA.call('AI', 'checkAISubscription', { playerId: OMEGA.player.playerId }); },
    async setUserKey(apiKey, model) { return OMEGA.call('AI', 'setUserAIKey', { playerId: OMEGA.player.playerId, apiKey, model }); },
    async getUserStatus() { return OMEGA.call('AI', 'getUserAIStatus', { playerId: OMEGA.player.playerId }); },
    async checkDoomsdaySurvival() { return OMEGA.call('AI', 'checkDoomsdaySurvival', { playerId: OMEGA.player.playerId }); },
    async loginDevice(deviceId, deviceName, platform) { return OMEGA.call('AI', 'loginDevice', { playerId: OMEGA.player.playerId, deviceId, deviceName, platform }); },
  },

  // === ADMIN ACTIONS ===
  admin: {
    async status() { return OMEGA.call('ADMIN', 'adminStatus', {}); },
    async setup(username, password) { return OMEGA.call('ADMIN', 'setupAdmin', { username, password }); },
    async login(username, password) { 
      const r = await OMEGA.call('ADMIN', 'adminLogin', { username, password });
      if (r.success && r.token) { OMEGA.player.adminToken = r.token; localStorage.setItem('omega8d_admin_token', r.token); }
      return r;
    },
    async verify(token) { return OMEGA.call('ADMIN', 'verifyAdmin', { token: token || OMEGA.player.adminToken }); },
    async changePassword(current, newPass) { return OMEGA.call('ADMIN', 'changeAdminPassword', { currentPassword: current, newPassword: newPass }); },
    isLoggedIn() { return !!OMEGA.player.adminToken; },
    logout() { OMEGA.player.adminToken = ''; localStorage.removeItem('omega8d_admin_token'); },
  },

  // === BALANCE SECURITY (anti-hack signed balances) ===
  balance: {
    async sign(playerId, balance) {
      try {
        const res = await fetch('/api/balance/sign', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ playerId, balance }),
        });
        return await res.json();
      } catch (e) { return { signature: null }; }
    },
    async verify(playerId, balance, signature) {
      try {
        const res = await fetch('/api/balance/verify', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ playerId, balance, signature }),
        });
        return await res.json();
      } catch (e) { return { valid: true }; } // Allow if server not available
    },
  },

  // === ANTI-CHEAT ACTION VALIDATION ===
  async validateAction(action, data = {}) {
    // If running on Replit, use local anti-cheat
    if (IS_REPLIT) {
      try {
        const res = await fetch('/api/game/action', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ action, playerId: this.player.playerId, data }),
        });
        return await res.json();
      } catch (e) { return { valid: true }; }
    }
    return { valid: true };
  },

  isAdminRoute() { return window.location.pathname.includes('/admin') || window.location.hash === '#admin'; },
};

// Auto-init if player ID exists
if (OMEGA.player.playerId) {
  OMEGA.initPlayer(OMEGA.player.playerId).then(() => {
    console.log('OMEGA-8D systems initialized:', OMEGA.player);
    console.log('AI source:', OMEGA.aiOnline ? 'Local WhiteRabbit (Replit)' : 'Base44 backend');
    window.dispatchEvent(new CustomEvent('omegaReady', { detail: OMEGA.player }));
  });
}

// Export
if (typeof window !== 'undefined') window.OMEGA = OMEGA;
if (typeof module !== 'undefined' && module.exports) module.exports = OMEGA;