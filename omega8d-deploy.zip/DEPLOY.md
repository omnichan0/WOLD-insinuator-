# OMEGA-8D — Zero-Config Replit Deployment Guide

## What This Does

When you hit "Run" on Replit, ALL of this happens automatically:
1. llama.cpp is cloned and compiled
2. WhiteRabbit model (3.8GB) is downloaded (first time only — ~10 min)
3. AI server starts on port 8081 (WhiteRabbit)
4. Game server starts on port 8080 (with security + PWA)
5. Keep-alive daemon starts (prevents Replit sleep)
6. Game is live on the internet — anyone can visit and play

## ZERO CONFIG NEEDED

- No pasting URLs into admin panel
- No setting API keys for the admin
- No manual endpoint configuration
- The game auto-detects it's on Replit and connects to WhiteRabbit
- Players can optionally add their own Groq free key for personal AI

## How To Deploy

1. Create a new Repl on replit.com (choose "Bash" template)

2. Upload these files to the Replit root:
   - .replit
   - start.sh
   - server.js
   - keepalive.sh
   - package.json

3. Create a folder called `game/` and upload your OMEGA-8D files:
   - game/chronofall/index.html
   - game/chronofall/*.js (all 29 JS files)
   - game/chronofall/*.md (setup docs)

4. Hit the green "Run" button

5. Wait for WhiteRabbit to download (first time only, ~10 min)

6. Your game is live! The URL looks like:
   https://your-repl-name.your-username.repl.co

7. Anyone on the internet can:
   - Visit the URL and play
   - Install as PWA on their phone/desktop
   - Use AI features (WhiteRabbit, auto-wired)
   - Add their own Groq key for personal AI

## Security Features

1. Anti-hack: Rate limiting on all API endpoints (100 req/min)
2. Anti-scrape: Blocks curl, wget, bots, crawlers
3. Anti-hotlink: Prevents other sites from embedding your game
4. Anti-cheat: Validates game actions (impossible damage, speed hacks, negative coins)
5. Balance signing: HMAC-signed balance values to detect tampering
6. Input sanitization: XSS and injection protection on all inputs
7. Security headers: Helmet (CSP, XSS-Protection, Frame-Options)
8. Auth rate limiting: 5 login attempts per 5 minutes

## PWA (Progressive Web App)

- Installable on any device (Android, iOS, Desktop)
- Works offline (service worker caches game files)
- Native app experience (standalone display)
- Custom theme color and app icon
- "Install" button appears automatically after 3 seconds

## Keep-Alive Daemon

- Pings the server every 10 minutes
- Auto-restarts WhiteRabbit if it crashes
- Prevents Replit from sleeping after 15 min inactivity
- Also pings the public URL to keep it awake

## Fallback

If WhiteRabbit is downloading or restarting:
- The game automatically falls back to Base44 backend
- Players who have their own Groq key still get AI
- Game is fully playable without AI (AI is optional enhancement)

## File Structure

```
replit/
├── .replit           # Replit config
├── start.sh          # Auto-start everything
├── server.js         # Game server + AI proxy + security
├── keepalive.sh      # Prevent sleep daemon
├── package.json      # Node dependencies
├── game/
│   └── chronofall/   # All game files
│       ├── index.html
│       └── *.js (29 files)
└── llama.cpp/        # Auto-cloned
    ├── server        # Auto-built
    └── whiterabbit.gguf  # Auto-downloaded (3.8GB)
```