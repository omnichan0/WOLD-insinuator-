# OMEGA-8D Replit AI Server — WhiteRabbit

This Replit project runs the C++ Llama (llama.cpp) server with the WhiteRabbit model.

## Quick Start

1. Create a new Repl (Bash template)
2. Upload `replit_whiterabbit.sh` and `replit_start.sh` 
3. In the Replit shell, run:
```bash
bash replit_whiterabbit.sh
```

4. Wait for the download (3.8GB, takes 5-15 min depending on connection)
5. Server starts automatically on port 8080

## Connect to OMEGA-8D

In your game's Admin Panel:
1. Go to AI Config tab
2. Set endpoint to: `https://YOUR_REPL_NAME.YOUR_USERNAME.repl.co/completion`
3. Set model to: `whiterabbit`
4. Save

## About WhiteRabbit

WhiteRabbit is an uncensored model that won't flag game content:
- No content restrictions on combat/violence
- Fast inference on CPU
- 3.8GB GGUF format (Q4_K_M quantization)
- 7B parameters, 4096 context window
- Works on Replit free tier (CPU only)

## Keep Alive

Replit free tier sleeps after inactivity. To keep it alive:
- Add a `.replit` file with `run = "bash replit_start.sh"`
- Use a free uptime monitor like UptimeRobot to ping the health endpoint every 5 min

## Alternative Models

If WhiteRabbit download fails, try these uncensored alternatives:

```bash
# Llama 3.1 8B (3.9GB)
wget -O model.gguf "https://huggingface.co/QuantFactory/Meta-Llama-3.1-8B-Instruct-GGUF/resolve/main/Meta-Llama-3.1-8B-Instruct.Q4_K_M.gguf"

# Dolphin Mistral 7B (4.4GB) — uncensored
wget -O model.gguf "https://huggingface.co/TheBloke/dolphin-2.2-mistral-7B-GGUF/resolve/main/dolphin-2.2-mistral-7b.Q4_K_M.gguf"

# OpenHermes 2.5 Mistral 7B (4.4GB)
wget -O model.gguf "https://huggingface.co/TheBloke/OpenHermes-2.5-Mistral-7B-GGUF/resolve/main/openhermes-2.5-mistral-7b.Q4_K_M.gguf"
```
