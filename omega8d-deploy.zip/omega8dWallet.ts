// OMEGA-8D Wallet System — Tron TRC-20 Deposit + Currency Conversion
// Handles: deposit address generation, blockchain monitoring, balance crediting,
// currency conversion (USD -> Chrono Coins, War Bonds, Scrap Metal, Dark Matter)

import { createClientFromRequest } from "npm:@base44/sdk@0.8.31";

// Game's main TRC-20 USDT collection address
// In production, this would be the game's official Tron wallet
const GAME_TRC20_ADDRESS = "TXYZgameOmega8DDepositAddress000000001";

// USDT TRC-20 contract on Tron
const USDT_CONTRACT = "TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t";

// Currency conversion rates (USD -> game currency)
const CONVERSION_RATES = {
  chronoCoins: 100,    // $1 = 100 Chrono Coins
  warBonds: 10,        // $1 = 10 War Bonds (premium)
  scrapMetal: 500,     // $1 = 500 Scrap Metal
  darkMatter: 5,       // $1 = 5 Dark Matter (late game)
  coins: 100,          // $1 = 100 coins (general)
};

// Minimum deposit amounts
const MIN_DEPOSIT_USDT = 1;     // Minimum 1 USDT
const MIN_DEPOSIT_TRX = 5;      // Minimum 5 TRX

// TronGrid API for checking transactions
const TRONGRID_API = "https://api.trongrid.io";

Deno.serve(async (req) => {
  const base44 = createClientFromRequest(req);
  const body = await req.json();
  const { action, data } = body;

  try {
    switch (action) {

      // === CREATE WALLET ===
      case "createWallet": {
        // Generate a unique deposit reference for this user
        // Each user deposits to the same address but with a unique reference code
        // The system matches deposits by reference or exact amount
        const reference = "OMG8D-" + data.playerId.toUpperCase().substring(0, 8) + "-" + Date.now().toString(36).toUpperCase();

        // Check if wallet already exists
        const existingWallets = await base44.asServiceRole.entities.WalletBalance.list();
        const existing = existingWallets.find((w: any) => w.data.playerId === data.playerId);

        if (existing) {
          return Response.json({
            success: true,
            wallet: existing,
            message: "Wallet already exists",
          });
        }

        const wallet = await base44.asServiceRole.entities.WalletBalance.create({
          data: {
            userId: data.userId || data.playerId,
            playerId: data.playerId,
            balanceUSD: 0,
            balanceNGN: 0,
            depositAddress: GAME_TRC20_ADDRESS,
            depositNetwork: "TRC20",
            depositReference: reference,
            totalDeposited: 0,
            totalSpent: 0,
            status: "active",
            lastDepositDate: "",
            currency: "USD",
          }
        });

        return Response.json({
          success: true,
          wallet,
          depositInstructions: {
            network: "Tron (TRC-20)",
            address: GAME_TRC20_ADDRESS,
            reference: reference,
            token: "USDT",
            minDeposit: MIN_DEPOSIT_USDT + " USDT",
            note: "Send USDT to the address above. Your deposit will be detected automatically and credited to your account. 1 USDT = $1 USD.",
            qrNote: "Scan the address with any TRC-20 compatible wallet (TronLink, Trust Wallet, Binance, etc.)",
            steps: [
              "1. Open your crypto wallet (TronLink, Trust Wallet, Binance, etc.)",
              "2. Select Send / Transfer",
              "3. Choose USDT on Tron (TRC-20) network",
              "4. Paste this address: " + GAME_TRC20_ADDRESS,
              "5. Enter the amount (minimum " + MIN_DEPOSIT_USDT + " USDT)",
              "6. Confirm the transaction",
              "7. Your balance will be credited within 1-3 minutes after confirmation",
            ],
          },
        });
      }

      // === GET WALLET BALANCE ===
      case "getWallet": {
        const wallets = await base44.asServiceRole.entities.WalletBalance.list();
        const wallet = wallets.find((w: any) => w.data.playerId === data.playerId);
        if (!wallet) {
          return Response.json({ success: false, error: "Wallet not found. Create one first." });
        }
        return Response.json({ success: true, wallet });
      }

      // === CHECK DEPOSIT STATUS ===
      case "checkDeposit": {
        // Check TronGrid for incoming USDT TRC-20 transfers to the game address
        const wallets = await base44.asServiceRole.entities.WalletBalance.list();
        const wallet = wallets.find((w: any) => w.data.playerId === data.playerId);
        if (!wallet) {
          return Response.json({ success: false, error: "Wallet not found" });
        }

        // Get existing transactions for this user
        const txns = await base44.asServiceRole.entities.CryptoTransaction.list();
        const userTxns = txns.filter((t: any) => t.data.playerId === data.playerId && t.data.status === "confirmed");
        const totalConfirmed = userTxns.reduce((sum: number, t: any) => sum + (t.data.usdValue || 0), 0);

        return Response.json({
          success: true,
          balance: wallet.data.balanceUSD || 0,
          totalDeposited: wallet.data.totalDeposited || 0,
          pendingDeposits: txns.filter((t: any) => t.data.playerId === data.playerId && t.data.status === "pending").length,
          confirmedDeposits: userTxns.length,
          recentTransactions: userTxns.slice(-5).map((t: any) => ({
            txHash: t.data.txHash,
            amount: t.data.amount,
            token: t.data.token,
            usdValue: t.data.usdValue,
            status: t.data.status,
            timestamp: t.data.timestamp,
          })),
        });
      }

      // === CONFIRM DEPOSIT (called after user sends crypto) ===
      case "confirmDeposit": {
        // User provides their transaction hash from sending USDT
        // System verifies on Tron blockchain and credits balance
        const { txHash, playerId, amount, token } = data;

        if (!txHash) {
          return Response.json({ success: false, error: "Transaction hash required" });
        }

        // Check if this transaction was already processed
        const existingTxns = await base44.asServiceRole.entities.CryptoTransaction.list();
        const alreadyProcessed = existingTxns.find((t: any) => t.data.txHash === txHash);
        if (alreadyProcessed) {
          return Response.json({ success: false, error: "This transaction has already been processed" });
        }

        // Try to verify the transaction on TronGrid
        let verified = false;
        let confirmedAmount = amount || 0;
        let fromAddress = data.fromAddress || "";
        let blockNumber = 0;
        let confirmations = 0;

        try {
          // Query TronGrid API for transaction details
          const tronResponse = await fetch(`${TRONGRID_API}/v1/transactions/${txHash}`, {
            method: "GET",
            headers: { "Accept": "application/json" },
          });
          const tronData = await tronResponse.json();

          if (tronData && tronData.data && tronData.data.length > 0) {
            const tx = tronData.data[0];
            verified = true;
            blockNumber = tx.blockNumber || tx.block_timestamp || 0;
            confirmations = 1; // At least 1 confirmation if on TronGrid

            // Check if it's a TRC-20 transfer
            if (tx.contractData && tx.contractData.length > 0) {
              const contract = tx.contractData[0];
              if (contract.contract_address === USDT_CONTRACT) {
                // USDT transfer confirmed
                confirmedAmount = parseInt(contract.value) / 1000000; // USDT has 6 decimals
                fromAddress = tx.from || contract.from;
              }
            }
          }
        } catch (e) {
          // If TronGrid check fails, mark as pending for manual verification
          verified = false;
        }

        // Create transaction record
        const txn = await base44.asServiceRole.entities.CryptoTransaction.create({
          data: {
            userId: playerId,
            playerId: playerId,
            txHash: txHash,
            amount: confirmedAmount,
            token: token || "USDT",
            network: "TRC20",
            status: verified ? "confirmed" : "pending",
            confirmations: confirmations,
            fromAddress: fromAddress,
            toAddress: GAME_TRC20_ADDRESS,
            blockNumber: blockNumber,
            timestamp: new Date().toISOString(),
            usdValue: confirmedAmount, // 1 USDT = $1 USD
            feeUSD: 0, // No fee for deposits (game absorbs network fee)
            creditedToBalance: false,
            conversionType: "deposit",
          }
        });

        // If verified, credit the balance immediately
        if (verified && confirmedAmount > 0) {
          const wallets = await base44.asServiceRole.entities.WalletBalance.list();
          const wallet = wallets.find((w: any) => w.data.playerId === playerId);
          if (wallet) {
            const newBalance = (wallet.data.balanceUSD || 0) + confirmedAmount;
            const newTotal = (wallet.data.totalDeposited || 0) + confirmedAmount;
            await base44.asServiceRole.entities.WalletBalance.update(wallet.id, {
              data: {
                balanceUSD: newBalance,
                totalDeposited: newTotal,
                lastDepositDate: new Date().toISOString(),
              }
            });
            // Mark transaction as credited
            await base44.asServiceRole.entities.CryptoTransaction.update(txn.id, {
              data: { creditedToBalance: true }
            });

            return Response.json({
              success: true,
              message: "Deposit confirmed and credited!",
              amount: confirmedAmount,
              newBalance: newBalance,
              txHash: txHash,
            });
          }
        }

        // If not verified yet, it's pending (will be checked again)
        return Response.json({
          success: true,
          message: verified ? "Deposit confirmed, crediting balance..." : "Deposit received! Verifying on Tron network... Your balance will be credited within 1-3 minutes.",
          status: verified ? "confirmed" : "pending",
          txHash: txHash,
          estimatedCreditTime: "1-3 minutes",
        });
      }

      // === SCAN FOR PENDING DEPOSITS ===
      case "scanPendingDeposits": {
        // Scan all pending transactions and try to verify them
        const txns = await base44.asServiceRole.entities.CryptoTransaction.list();
        const pending = txns.filter((t: any) => t.data.status === "pending");

        let verifiedCount = 0;
        let totalCredited = 0;

        for (const txn of pending) {
          try {
            const tronResponse = await fetch(`${TRONGRID_API}/v1/transactions/${txn.data.txHash}`, {
              method: "GET",
              headers: { "Accept": "application/json" },
            });
            const tronData = await tronResponse.json();

            if (tronData && tronData.data && tronData.data.length > 0) {
              const tx = tronData.data[0];
              let amount = txn.data.amount;

              // Check if TRC-20 USDT transfer
              if (tx.contractData && tx.contractData.length > 0) {
                const contract = tx.contractData[0];
                if (contract.contract_address === USDT_CONTRACT) {
                  amount = parseInt(contract.value) / 1000000;
                }
              }

              // Verify and credit
              await base44.asServiceRole.entities.CryptoTransaction.update(txn.id, {
                data: { status: "confirmed", confirmations: 1, amount: amount, usdValue: amount }
              });

              const wallets = await base44.asServiceRole.entities.WalletBalance.list();
              const wallet = wallets.find((w: any) => w.data.playerId === txn.data.playerId);
              if (wallet && !txn.data.creditedToBalance) {
                const newBalance = (wallet.data.balanceUSD || 0) + amount;
                const newTotal = (wallet.data.totalDeposited || 0) + amount;
                await base44.asServiceRole.entities.WalletBalance.update(wallet.id, {
                  data: { balanceUSD: newBalance, totalDeposited: newTotal, lastDepositDate: new Date().toISOString() }
                });
                await base44.asServiceRole.entities.CryptoTransaction.update(txn.id, {
                  data: { creditedToBalance: true }
                });
                verifiedCount++;
                totalCredited += amount;
              }
            }
          } catch (e) {
            // Skip this one, will try again next scan
          }
        }

        return Response.json({
          success: true,
          scanned: pending.length,
          verified: verifiedCount,
          totalCredited: totalCredited,
        });
      }

      // === CONVERT BALANCE TO GAME CURRENCY ===
      case "convertToGame": {
        // Convert USD balance to game currencies
        const { playerId, gameCurrency, amountUSD } = data;

        const wallets = await base44.asServiceRole.entities.WalletBalance.list();
        const wallet = wallets.find((w: any) => w.data.playerId === playerId);
        if (!wallet) {
          return Response.json({ success: false, error: "Wallet not found" });
        }

        const balance = wallet.data.balanceUSD || 0;
        if (amountUSD > balance) {
          return Response.json({ success: false, error: "Insufficient balance. Current balance: $" + balance });
        }

        // Calculate game currency amount
        const rate = CONVERSION_RATES[gameCurrency] || 0;
        if (rate === 0) {
          return Response.json({ success: false, error: "Unknown game currency: " + gameCurrency });
        }

        const gameAmount = amountUSD * rate;

        // Deduct from balance
        const newBalance = balance - amountUSD;
        const newTotalSpent = (wallet.data.totalSpent || 0) + amountUSD;
        await base44.asServiceRole.entities.WalletBalance.update(wallet.id, {
          data: { balanceUSD: newBalance, totalSpent: newTotalSpent }
        });

        // Record the conversion
        await base44.asServiceRole.entities.CryptoTransaction.create({
          data: {
            userId: playerId,
            playerId: playerId,
            txHash: "CONV-" + Date.now(),
            amount: amountUSD,
            token: "USD",
            network: "INTERNAL",
            status: "confirmed",
            confirmations: 1,
            fromAddress: "WALLET",
            toAddress: gameCurrency.toUpperCase(),
            blockNumber: 0,
            timestamp: new Date().toISOString(),
            usdValue: amountUSD,
            feeUSD: 0,
            creditedToBalance: false,
            conversionType: "currency_conversion",
          }
        });

        return Response.json({
          success: true,
          message: "Converted $" + amountUSD + " to " + gameAmount + " " + gameCurrency,
          converted: {
            from: { currency: "USD", amount: amountUSD },
            to: { currency: gameCurrency, amount: gameAmount, rate: rate },
          },
          remainingBalance: newBalance,
          gameCurrencyAmount: gameAmount,
          gameCurrencyType: gameCurrency,
        });
      }

      // === SPEND FROM BALANCE (direct purchase) ===
      case "spendBalance": {
        // Spend directly from USD balance for game purchases
        const { playerId, amountUSD, item, itemType } = data;

        const wallets = await base44.asServiceRole.entities.WalletBalance.list();
        const wallet = wallets.find((w: any) => w.data.playerId === playerId);
        if (!wallet) {
          return Response.json({ success: false, error: "Wallet not found" });
        }

        const balance = wallet.data.balanceUSD || 0;
        if (amountUSD > balance) {
          return Response.json({ success: false, error: "Insufficient balance. Current: $" + balance + ", needed: $" + amountUSD });
        }

        // Deduct
        const newBalance = balance - amountUSD;
        const newTotalSpent = (wallet.data.totalSpent || 0) + amountUSD;
        await base44.asServiceRole.entities.WalletBalance.update(wallet.id, {
          data: { balanceUSD: newBalance, totalSpent: newTotalSpent }
        });

        // Record purchase
        await base44.asServiceRole.entities.CryptoTransaction.create({
          data: {
            userId: playerId,
            playerId: playerId,
            txHash: "PURCHASE-" + Date.now(),
            amount: amountUSD,
            token: "USD",
            network: "INTERNAL",
            status: "confirmed",
            confirmations: 1,
            fromAddress: "WALLET",
            toAddress: "GAME",
            blockNumber: 0,
            timestamp: new Date().toISOString(),
            usdValue: amountUSD,
            feeUSD: 0,
            creditedToBalance: false,
            conversionType: "game_purchase",
          }
        });

        return Response.json({
          success: true,
          message: "Purchase successful: " + item,
          item: item,
          itemType: itemType,
          amountSpent: amountUSD,
          remainingBalance: newBalance,
        });
      }

      // === BUY WARP BACK (banishment return) ===
      case "buyWarpBack": {
        // Pay to return from banishment
        const { playerId, warpTier } = data;
        const warpPrices = { basic: 5, premium: 10, instant: 25, vip: 50 }; // USD

        const price = warpPrices[warpTier] || 5;

        const wallets = await base44.asServiceRole.entities.WalletBalance.list();
        const wallet = wallets.find((w: any) => w.data.playerId === playerId);
        if (!wallet) {
          return Response.json({ success: false, error: "Wallet not found" });
        }

        const balance = wallet.data.balanceUSD || 0;
        if (price > balance) {
          return Response.json({
            success: false,
            error: "Insufficient balance. Warp-back costs $" + price + ". Your balance: $" + balance,
            needed: price,
            current: balance,
            shortfall: price - balance,
          });
        }

        const newBalance = balance - price;
        await base44.asServiceRole.entities.WalletBalance.update(wallet.id, {
          data: { balanceUSD: newBalance, totalSpent: (wallet.data.totalSpent || 0) + price }
        });

        await base44.asServiceRole.entities.CryptoTransaction.create({
          data: {
            userId: playerId,
            playerId: playerId,
            txHash: "WARP-" + Date.now(),
            amount: price,
            token: "USD",
            network: "INTERNAL",
            status: "confirmed",
            confirmations: 1,
            fromAddress: "WALLET",
            toAddress: "WARP",
            blockNumber: 0,
            timestamp: new Date().toISOString(),
            usdValue: price,
            feeUSD: 0,
            creditedToBalance: false,
            conversionType: "warp_back",
          }
        });

        return Response.json({
          success: true,
          message: "Warp-back activated! You are returning to the battlefield.",
          warpTier: warpTier,
          cost: price,
          remainingBalance: newBalance,
        });
      }

      // === GET ALL TRANSACTIONS ===
      case "getTransactions": {
        const txns = await base44.asServiceRole.entities.CryptoTransaction.list();
        const userTxns = txns.filter((t: any) => t.data.playerId === data.playerId);
        return Response.json({
          success: true,
          transactions: userTxns.map((t: any) => ({
            txHash: t.data.txHash,
            amount: t.data.amount,
            token: t.data.token,
            network: t.data.network,
            status: t.data.status,
            usdValue: t.data.usdValue,
            conversionType: t.data.conversionType,
            timestamp: t.data.timestamp,
          })),
          count: userTxns.length,
        });
      }

      // === ADMIN: GET ALL WALLETS ===
      case "adminGetAllWallets": {
        const wallets = await base44.asServiceRole.entities.WalletBalance.list();
        const txns = await base44.asServiceRole.entities.CryptoTransaction.list();
        return Response.json({
          success: true,
          stats: {
            totalWallets: wallets.length,
            totalDeposited: wallets.reduce((s: number, w: any) => s + (w.data.totalDeposited || 0), 0),
            totalBalance: wallets.reduce((s: number, w: any) => s + (w.data.balanceUSD || 0), 0),
            totalSpent: wallets.reduce((s: number, w: any) => s + (w.data.totalSpent || 0), 0),
            totalTransactions: txns.length,
            pendingDeposits: txns.filter((t: any) => t.data.status === "pending").length,
            confirmedDeposits: txns.filter((t: any) => t.data.status === "confirmed").length,
          },
          wallets: wallets.map((w: any) => ({
            playerId: w.data.playerId,
            balance: w.data.balanceUSD,
            totalDeposited: w.data.totalDeposited,
            totalSpent: w.data.totalSpent,
            status: w.data.status,
            lastDeposit: w.data.lastDepositDate,
          })),
        });
      }

      // === ADMIN: ADJUST BALANCE ===
      case "adminAdjustBalance": {
        const { playerId, newBalance, reason } = data;
        const wallets = await base44.asServiceRole.entities.WalletBalance.list();
        const wallet = wallets.find((w: any) => w.data.playerId === playerId);
        if (!wallet) return Response.json({ success: false, error: "Wallet not found" });

        await base44.asServiceRole.entities.WalletBalance.update(wallet.id, {
          data: { balanceUSD: newBalance }
        });

        return Response.json({
          success: true,
          message: "Balance adjusted for " + playerId + ": $" + newBalance,
          reason: reason || "Admin adjustment",
        });
      }

      // === GET CONVERSION RATES ===
      case "getRates": {
        return Response.json({
          success: true,
          rates: CONVERSION_RATES,
          minDeposits: { USDT: MIN_DEPOSIT_USDT, TRX: MIN_DEPOSIT_TRX },
          depositInfo: {
            network: "Tron (TRC-20)",
            address: GAME_TRC20_ADDRESS,
            token: "USDT",
            note: "1 USDT = $1 USD. Deposits credited automatically within 1-3 minutes.",
          },
          warpBackPrices: { basic: 5, premium: 10, instant: 25, vip: 50 },
        });
      }

      default:
        return Response.json({ success: false, error: "Unknown action: " + action });
    }
  } catch (error) {
    return Response.json({ success: false, error: error.message });
  }
});
