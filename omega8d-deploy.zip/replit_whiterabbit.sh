#!/bin/bash
# OMEGA-8D AI Server — Auto-installs C++ Llama + WhiteRabbit 3.8GB model
# Run this on Replit. It clones llama.cpp, downloads WhiteRabbit, and starts the server.

echo "=== OMEGA-8D AI SERVER SETUP ==="
echo "Model: WhiteRabbit (3.8GB GGUF)"
echo ""

# Step 1: Clone llama.cpp
echo "[1/5] Cloning llama.cpp..."
if [ ! -d "llama.cpp" ]; then
  git clone https://github.com/ggerganov/llama.cpp --depth 1
fi
cd llama.cpp

# Step 2: Build llama.cpp
echo "[2/5] Building llama.cpp..."
make -j$(nproc) 2>&1 | tail -5

# Step 3: Download WhiteRabbit model (3.8GB)
echo "[3/5] Downloading WhiteRabbit model (3.8GB)..."
if [ ! -f "whiterabbit.gguf" ]; then
  # WhiteRabbit-II-7B Q4_K_M GGUF (3.8GB)
  wget -q --show-progress -O whiterabbit.gguf \
    "https://huggingface.co/TheBloke/WhiteRabbit-II-7B-GGUF/resolve/main/whiterabbit-ii-7b.Q4_K_M.gguf"
  
  if [ ! -s whiterabbit.gguf ]; then
    echo "Trying alternate mirror..."
    wget -q --show-progress -O whiterabbit.gguf \
      "https://huggingface.co/TheBloke/WhiteRabbit-II-13B-GGUF/resolve/main/whiterabbit-ii-13b.Q4_0.gguf"
  fi
fi

# Check file size
SIZE=$(stat -c%s whiterabbit.gguf 2>/dev/null || stat -f%z whiterabbit.gguf 2>/dev/null || echo 0)
echo "Model size: $((SIZE / 1024 / 1024)) MB"

if [ "$SIZE" -lt 1000000000 ]; then
  echo "ERROR: Model download failed or incomplete. Trying Q3 version..."
  wget -q --show-progress -O whiterabbit.gguf \
    "https://huggingface.co/TheBloke/WhiteRabbit-II-7B-GGUF/resolve/main/whiterabbit-ii-7b.Q3_K_M.gguf"
fi

# Step 4: Start the server
echo "[4/5] Starting llama.cpp server on port 8080..."

# Kill any existing server
pkill -f "llama.*server" 2>/dev/null || true

# Start server with WhiteRabbit model
# -c 4096 = context window
# --host 0.0.0.0 = allow external connections (Replit)
# -ngl 0 = CPU only (Replit free tier has no GPU)
./server \
  -m whiterabbit.gguf \
  -c 4096 \
  --host 0.0.0.0 \
  --port 8080 \
  -ngl 0 \
  --metrics \
  2>&1 &

SERVER_PID=$!
sleep 3

# Step 5: Verify server is running
echo "[5/5] Verifying server..."
if curl -s http://localhost:8080/health > /dev/null 2>&1; then
  echo ""
  echo "=== SERVER IS LIVE ==="
  echo "Endpoint: http://localhost:8080/completion"
  echo "Health: http://localhost:8080/health"
  echo ""
  echo "In OMEGA-8D Admin Panel:"
  echo "  AI Endpoint: https://YOUR-REPLIT-URL/completion"
  echo "  AI Model: whiterabbit"
  echo ""
  echo "Server PID: $SERVER_PID"
else
  echo "Server still starting... waiting 10s"
  sleep 10
  if curl -s http://localhost:8080/health > /dev/null 2>&1; then
    echo "=== SERVER IS LIVE ==="
    echo "Endpoint: http://localhost:8080/completion"
  else
    echo "ERROR: Server failed to start. Check llama.cpp build."
  fi
fi