// OMEGA-8D Admin Auth — Simple username/password auth for /admin access
// Credentials stored in GameConfig entity (hashed with SHA-256)
import { createClientFromRequest } from "npm:@base44/sdk@0.8.31";

const getField = (e: any, f: string) => e?.data?.[f] ?? e?.[f] ?? null;

async function createRecord(base44: any, entityName: string, fields: any) {
  const created = await base44.asServiceRole.entities[entityName].create({ data: {} });
  await base44.asServiceRole.entities[entityName].update(created.id, fields as any);
  return created;
}

async function getConfig(base44: any, key: string) {
  const configs = await base44.asServiceRole.entities.GameConfig.list();
  const config = configs.find((c: any) => getField(c, "key") === key);
  return config ? getField(config, "value") : null;
}

async function setConfig(base44: any, key: string, value: string, description: string) {
  const configs = await base44.asServiceRole.entities.GameConfig.list();
  const existing = configs.find((c: any) => getField(c, "key") === key);
  if (existing) {
    await base44.asServiceRole.entities.GameConfig.update(existing.id, { value, description, updatedBy: "admin" } as any);
  } else {
    await createRecord(base44, "GameConfig", { key, value, category: "auth", description, updatedBy: "admin" });
  }
}

async function hashPassword(password: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode("omega8d_salt_" + password);
  const hash = await crypto.subtle.digest("SHA-256", data);
  return Array.from(new Uint8Array(hash)).map(b => b.toString(16).padStart(2, "0")).join("");
}

Deno.serve(async (req) => {
  const base44 = createClientFromRequest(req);
  const body = await req.json();
  const { action, data } = body;
  try {
    switch (action) {
      case "setupAdmin": {
        const { username, password } = data;
        if (!username || !password) return Response.json({ success: false, error: "Username and password required" });
        const existingUser = await getConfig(base44, "admin_username");
        const existingPass = await getConfig(base44, "admin_password_hash");
        if (existingUser && existingPass) return Response.json({ success: false, error: "Admin already configured. Use login instead." });
        const hashedPass = await hashPassword(password);
        await setConfig(base44, "admin_username", username, "Admin username");
        await setConfig(base44, "admin_password_hash", hashedPass, "Admin password hash (SHA-256)");
        return Response.json({ success: true, message: "Admin account created! Login at /admin" });
      }
      case "adminLogin": {
        const { username, password } = data;
        if (!username || !password) return Response.json({ success: false, error: "Username and password required" });
        const storedUser = await getConfig(base44, "admin_username");
        const storedHash = await getConfig(base44, "admin_password_hash");
        if (!storedUser || !storedHash) return Response.json({ success: false, error: "Admin not configured. Call setupAdmin first." });
        if (username !== storedUser) return Response.json({ success: false, error: "Invalid credentials" });
        const inputHash = await hashPassword(password);
        if (inputHash !== storedHash) return Response.json({ success: false, error: "Invalid credentials" });
        const token = "ADM-" + Date.now() + "-" + Math.random().toString(36).substring(2, 12);
        await setConfig(base44, "admin_session_token", token, "Current admin session token");
        await setConfig(base44, "admin_session_expiry", new Date(Date.now() + 86400000).toISOString(), "Session expires in 24h");
        return Response.json({ success: true, message: "Login successful!", token, expiresIn: "24h" });
      }
      case "verifyAdmin": {
        const { token } = data;
        if (!token) return Response.json({ success: false, error: "No token" });
        const storedToken = await getConfig(base44, "admin_session_token");
        const expiry = await getConfig(base44, "admin_session_expiry");
        if (!storedToken || storedToken !== token) return Response.json({ success: false, error: "Invalid session" });
        if (expiry && new Date(expiry) < new Date()) return Response.json({ success: false, error: "Session expired" });
        return Response.json({ success: true, message: "Session valid", admin: await getConfig(base44, "admin_username") });
      }
      case "changeAdminPassword": {
        const { currentPassword, newPassword } = data;
        const storedHash = await getConfig(base44, "admin_password_hash");
        if (!storedHash) return Response.json({ success: false, error: "Admin not configured" });
        const currentHash = await hashPassword(currentPassword);
        if (currentHash !== storedHash) return Response.json({ success: false, error: "Current password incorrect" });
        const newHash = await hashPassword(newPassword);
        await setConfig(base44, "admin_password_hash", newHash, "Admin password hash (SHA-256)");
        return Response.json({ success: true, message: "Password changed!" });
      }
      case "adminStatus": {
        const user = await getConfig(base44, "admin_username");
        const hasPass = await getConfig(base44, "admin_password_hash");
        return Response.json({ success: true, configured: !!(user && hasPass), username: user || null });
      }
      default:
        return Response.json({ success: false, error: "Unknown action: " + action });
    }
  } catch (error) { return Response.json({ success: false, error: error.message }); }
});