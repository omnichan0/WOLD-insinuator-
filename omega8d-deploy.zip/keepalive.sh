#!/bin/bash
# OMEGA-8D Keep-Alive + Self-Heal Daemon — pings every 1 MINUTE
# Prevents Replit sleep AND auto-restarts crashed servers

SELF_URL="http://localhost:8080/health"
AI_URL="http://127.0.0.1:8081/health"

while true; do
  # 1. Ping game server health
  GAME_ALIVE=$(curl -s -o /dev/null -w "%{http_code}" "$SELF_URL" 2>/dev/null)
  
  # SELF-HEAL: restart game server if dead
  if [ "$GAME_ALIVE" != "200" ]; then
    echo "[$(date)] Game server down ($GAME_ALIVE) — SELF-HEAL: restarting..."
    pkill -f "node server.js" 2>/dev/null
    sleep 2
    cd /home/runner/$(basename $REPL_SLUG 2>/dev/null || echo .) 2>/dev/null || cd ~
    nohup node server.js > /dev/null 2>&1 &
    echo "[$(date)] Game server restarted (PID: $!)"
  fi
  
  # 2. SELF-HEAL: restart WhiteRabbit AI if dead
  AI_ALIVE=$(curl -s -o /dev/null -w "%{http_code}" "$AI_URL" 2>/dev/null)
  
  if [ "$AI_ALIVE" != "200" ]; then
    echo "[$(date)] AI server down ($AI_ALIVE) — SELF-HEAL: restarting WhiteRabbit..."
    pkill -f "llama.*server" 2>/dev/null
    sleep 2
    if [ -f "llama.cpp/whiterabbit.gguf" ]; then
      cd llama.cpp
      nohup ./server -m whiterabbit.gguf -c 4096 --host 127.0.0.1 --port 8081 -ngl 0 > /dev/null 2>&1 &
      echo "[$(date)] WhiteRabbit restarted (PID: $!)"
      cd ..
    fi
  fi
  
  # 3. Ping public URL to keep Replit awake externally
  if [ ! -z "$REPL_SLUG" ] && [ ! -z "$REPL_OWNER" ]; then
    curl -s "https://${REPL_SLUG}.${REPL_OWNER}.repl.co/health" > /dev/null 2>&1
  fi
  
  # 1 MINUTE interval
  sleep 60
done