// OMEGA-8D Topological Map Persistence API — FULL VERSION with Dynamic + AI
import { createClientFromRequest } from "npm:@base44/sdk@0.8.31";

Deno.serve(async (req) => {
  const base44 = createClientFromRequest(req);
  const body = await req.json();
  const { action, data } = body;

  try {
    switch (action) {
      // === ZONE TOPOLOGY ===
      case "createZone": {
        const zone = await base44.asServiceRole.entities.ZoneTopology.create({
          data: {
            zoneId: data.zoneId, zoneName: data.zoneName, bounds: data.bounds,
            baseTerrain: data.baseTerrain || "unknown", baseElevation: data.baseElevation || 0,
            modifications: [], modificationCount: 0, topologyHash: "init-" + Date.now(),
            lastModified: new Date().toISOString(),
          }
        });
        return Response.json({ success: true, zone });
      }
      case "getZone": {
        const zones = await base44.asServiceRole.entities.ZoneTopology.list();
        const zone = zones.find((z: any) => z.data.zoneId === data.zoneId);
        return Response.json({ success: true, zone: zone || null });
      }
      case "createModification": {
        const mod = await base44.asServiceRole.entities.MapModification.create({
          data: {
            modId: data.modId, zoneId: data.zoneId, zoneName: data.zoneName, type: data.type,
            coords: data.coords, severity: data.severity, radius: data.radius,
            createdBy: data.createdBy, creatorTag: data.creatorTag,
            createdDate: new Date().toISOString(), matchId: data.matchId || "",
            visualEffect: data.visualEffect || "", blocksMovement: data.blocksMovement || false,
            blocksSight: data.blocksSight || false, providesCover: data.providesCover || false,
            dimensionalLock: data.dimensionalLock || false, expiryDate: null,
            affectedCells: data.affectedCells || [],
          }
        });
        const zones = await base44.asServiceRole.entities.ZoneTopology.list();
        const zone = zones.find((z: any) => z.data.zoneId === data.zoneId);
        if (zone) {
          const modifications = [...(zone.data.modifications || []), data.modId];
          const modificationCount = (zone.data.modificationCount || 0) + 1;
          await base44.asServiceRole.entities.ZoneTopology.update(zone.id, {
            data: { modifications, modificationCount, topologyHash: "v" + modificationCount + "-" + Date.now(), lastModified: new Date().toISOString() }
          });
        }
        return Response.json({ success: true, mod });
      }
      case "getZoneMods": {
        const mods = await base44.asServiceRole.entities.MapModification.list();
        return Response.json({ success: true, mods: mods.filter((m: any) => m.data.zoneId === data.zoneId) });
      }

      // === PLAYER PROFILES ===
      case "createPlayer": {
        const player = await base44.asServiceRole.entities.PlayerProfile.create({
          data: {
            playerId: data.playerId, name: data.name, countries: data.countries || [],
            careers: data.careers || {}, primaryCareer: data.primaryCareer || "",
            careerTier: data.careerTier || "", coins: data.coins || 0,
            premiumTokens: data.premiumTokens || 0, weapons: data.weapons || [],
            skills: data.skills || [], gear: data.gear || [], achievements: data.achievements || [],
            titles: data.titles || [], ariaOwned: data.ariaOwned || false, xp: data.xp || 0,
            currentMatch: "", notifications: [], createdAt: new Date().toISOString(),
          }
        });
        return Response.json({ success: true, player });
      }
      case "getPlayer": {
        const players = await base44.asServiceRole.entities.PlayerProfile.list();
        const player = players.find((p: any) => p.data.playerId === data.playerId);
        return Response.json({ success: true, player: player || null });
      }
      case "joinCountry": {
        const players = await base44.asServiceRole.entities.PlayerProfile.list();
        const player = players.find((p: any) => p.data.playerId === data.playerId);
        if (player) {
          const countries = [...(player.data.countries || [])];
          if (!countries.includes(data.country)) countries.push(data.country);
          const careers = { ...(player.data.careers || {}) };
          careers[data.country] = data.career;
          await base44.asServiceRole.entities.PlayerProfile.update(player.id, { data: { countries, careers } });
          return Response.json({ success: true, countries, careers });
        }
        return Response.json({ success: false, error: "Player not found" });
      }

      // === RECRUITMENT ===
      case "createBanner": {
        const banner = await base44.asServiceRole.entities.RecruitmentBanner.create({
          data: { bannerId: "BANNER-" + Date.now(), type: data.type, country: data.country,
            campaignName: data.campaignName || "", commander: data.commander,
            description: data.description || "", requirements: data.requirements || {},
            applicants: [], status: "OPEN", createdAt: new Date().toISOString() }
        });
        return Response.json({ success: true, banner });
      }
      case "getBanners": {
        const banners = await base44.asServiceRole.entities.RecruitmentBanner.list();
        return Response.json({ success: true, banners: banners.filter((b: any) => b.data.status === "OPEN") });
      }
      case "applyToBanner": {
        const banners = await base44.asServiceRole.entities.RecruitmentBanner.list();
        const banner = banners.find((b: any) => b.data.bannerId === data.bannerId);
        if (banner) {
          const applicants = [...(banner.data.applicants || []), { playerId: data.playerId, name: data.name, career: data.career, rank: data.rank, kdr: data.kdr, appliedAt: new Date().toISOString() }];
          await base44.asServiceRole.entities.RecruitmentBanner.update(banner.id, { data: { applicants } });
          return Response.json({ success: true, applicants });
        }
        return Response.json({ success: false, error: "Banner not found" });
      }

      // === MATCHES ===
      case "createMatch": {
        const match = await base44.asServiceRole.entities.MatchRecord.create({
          data: { matchId: "MATCH-" + Date.now(), zoneId: data.zoneId, teams: data.teams || [],
            winCondition: data.winCondition || "LAST_TEAM_STANDING", status: "STARTING",
            startTime: new Date().toISOString(), endTime: "", participants: data.participants || [], winnerId: "" }
        });
        return Response.json({ success: true, match });
      }
      case "endMatch": {
        const matches = await base44.asServiceRole.entities.MatchRecord.list();
        const match = matches.find((m: any) => m.data.matchId === data.matchId);
        if (match) {
          await base44.asServiceRole.entities.MatchRecord.update(match.id, { data: { status: "COMPLETED", endTime: new Date().toISOString(), winnerId: data.winnerId || "" } });
          return Response.json({ success: true });
        }
        return Response.json({ success: false, error: "Match not found" });
      }

      // === GLOBAL STATS ===
      case "getGlobalStats": {
        const [zones, mods, players, banners, matches, aiBehaviors] = await Promise.all([
          base44.asServiceRole.entities.ZoneTopology.list(),
          base44.asServiceRole.entities.MapModification.list(),
          base44.asServiceRole.entities.PlayerProfile.list(),
          base44.asServiceRole.entities.RecruitmentBanner.list(),
          base44.asServiceRole.entities.MatchRecord.list(),
          base44.asServiceRole.entities.AIBehavior.list(),
        ]);
        return Response.json({ success: true, stats: {
          totalZones: zones.length, totalModifications: mods.length, totalPlayers: players.length,
          activeBanners: banners.filter((b: any) => b.data.status === "OPEN").length,
          totalMatches: matches.length,
          activeMatches: matches.filter((m: any) => m.data.status === "STARTING" || m.data.status === "ACTIVE").length,
          aiSubscribers: aiBehaviors.filter((a: any) => a.data.subscriptionActive === true).length,
        }});
      }

      // === DYNAMIC EVENT GENERATION ===
      case "generateEvent": {
        const events = [
          { type: "CIVILIAN_UPRISING", desc: "Armed civilians form defense ring", urgency: "high", effect: "civilian_militia_spawn", count: Math.floor(Math.random() * 50) + 10 },
          { type: "DIMENSIONAL_RIFT", desc: "Random dimensional rift opens", urgency: "high", effect: "dimension_open", location: { x: Math.random() * 1000, z: Math.random() * 1000 } },
          { type: "ENEMY_REINFORCEMENTS", desc: "Enemy reinforcements incoming", urgency: "high", effect: "enemy_spawn", count: Math.floor(Math.random() * 8) + 4, direction: ["north","south","east","west"][Math.floor(Math.random()*4)] },
          { type: "SUPPLY_DROP", desc: "Unmarked supply drop falling from orbit", urgency: "high", effect: "supply_drop", location: { x: Math.random() * 1000, z: Math.random() * 1000 } },
          { type: "SATELLITE_REVEAL", desc: "Military satellite scanned the zone — everyone visible for 10s", urgency: "critical", effect: "full_reveal", duration: 10 },
          { type: "GHOST_SIGNAL", desc: "Someone who should be dead is transmitting", urgency: "critical", effect: "ghost_player" },
        ];
        return Response.json({ success: true, event: events[Math.floor(Math.random() * events.length)] });
      }
      case "generateDynamicMatch": {
        const modifiers = ["fog_of_war", "double_agent", "time_dilation", "gravity_inversion", "perma_death", "night_ops", "bounty_hunters", "quantum_instability"];
        const weathers = ["clear", "rain", "storm", "fog", "snow", "sandstorm", "nuclear_fallout", "void_storm"];
        const aiBehaviors = ["flanking", "ambush", "berserk", "tactical_retreat", "dimensional_tactics", "swarm", "stealth_infiltration", "guerrilla"];
        return Response.json({ success: true, match: {
          event: { type: ["CIVILIAN_UPRISING", "ENEMY_REINFORCEMENTS", "SUPPLY_DROP", "SATELLITE_REVEAL"][Math.floor(Math.random()*4)] },
          modifiers: Array.from({length: Math.floor(Math.random()*3)+1}, () => modifiers[Math.floor(Math.random()*modifiers.length)]),
          aiBehavior: aiBehaviors[Math.floor(Math.random()*aiBehaviors.length)],
          weather: weathers[Math.floor(Math.random()*weathers.length)],
          seed: Math.floor(Math.random() * 999999999),
          generatedAt: new Date().toISOString(),
          note: "This match is entirely unpredictable. No two matches will ever be the same.",
        }});
      }

      // === AI BEHAVIOR ===
      case "createAIBehavior": {
        const ai = await base44.asServiceRole.entities.AIBehavior.create({
          data: {
            playerId: data.playerId, playstyle: data.playstyle || "balanced",
            difficulty: data.difficulty || "normal", subscriptionActive: data.subscriptionActive || false,
            subscriptionExpiry: data.subscriptionExpiry || "", aiKills: 0, aiDeaths: 0,
            aiWinRate: 0, cheatsUsed: 0, banishesPerformed: 0, survivalActivations: 0,
            strikesCalled: 0, totalAIPlaytime: 0, learnedPatterns: {},
          }
        });
        return Response.json({ success: true, ai });
      }
      case "getAIBehavior": {
        const ais = await base44.asServiceRole.entities.AIBehavior.list();
        const ai = ais.find((a: any) => a.data.playerId === data.playerId);
        return Response.json({ success: true, ai: ai || null });
      }
      case "updateAIBehavior": {
        const ais = await base44.asServiceRole.entities.AIBehavior.list();
        const ai = ais.find((a: any) => a.data.playerId === data.playerId);
        if (ai) {
          await base44.asServiceRole.entities.AIBehavior.update(ai.id, { data: {
            playstyle: data.playstyle || ai.data.playstyle,
            difficulty: data.difficulty || ai.data.difficulty,
            aiKills: data.aiKills !== undefined ? ai.data.aiKills + data.aiKills : ai.data.aiKills,
            aiDeaths: data.aiDeaths !== undefined ? ai.data.aiDeaths + data.aiDeaths : ai.data.aiDeaths,
            cheatsUsed: data.cheatsUsed !== undefined ? ai.data.cheatsUsed + data.cheatsUsed : ai.data.cheatsUsed,
            banishesPerformed: data.banishesPerformed !== undefined ? ai.data.banishesPerformed + data.banishesPerformed : ai.data.banishesPerformed,
            survivalActivations: data.survivalActivations !== undefined ? ai.data.survivalActivations + data.survivalActivations : ai.data.survivalActivations,
            strikesCalled: data.strikesCalled !== undefined ? ai.data.strikesCalled + data.strikesCalled : ai.data.strikesCalled,
            totalAIPlaytime: data.playtime !== undefined ? ai.data.totalAIPlaytime + data.playtime : ai.data.totalAIPlaytime,
            learnedPatterns: data.learnedPatterns || ai.data.learnedPatterns,
          }});
          return Response.json({ success: true, message: "AI behavior updated" });
        }
        return Response.json({ success: false, error: "AI behavior not found" });
      }
      case "activateAISubscription": {
        const ais = await base44.asServiceRole.entities.AIBehavior.list();
        const ai = ais.find((a: any) => a.data.playerId === data.playerId);
        if (ai) {
          await base44.asServiceRole.entities.AIBehavior.update(ai.id, { data: {
            subscriptionActive: true, subscriptionExpiry: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString()
          }});
          return Response.json({ success: true, message: "AI Auto-Play subscription activated for 1 year", price: "$300" });
        }
        return Response.json({ success: false, error: "AI behavior profile not found. Create one first." });
      }

      default:
        return Response.json({ success: false, error: "Unknown action: " + action });
    }
  } catch (error) {
    return Response.json({ success: false, error: error.message });
  }
});
