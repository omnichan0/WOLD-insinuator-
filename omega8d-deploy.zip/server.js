// OMEGA-8D — Unified Game Server with Security, PWA, and AI Proxy
// This serves the game HTML AND proxies AI requests to llama.cpp (WhiteRabbit)
// Zero config — just run on Replit and everything works.

const express = require('express');
const helmet = require('helmet');
const rateLimit = require('rate-limiter-flexible').RateLimiterMemory;
const path = require('path');
const crypto = require('crypto');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 8080;
const AI_PORT = 8081;

// ==========================================
// SECURITY MIDDLEWARE
// ==========================================

// Helmet for security headers
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'", "'unsafe-inline'", "'unsafe-eval'", "https:", "wss:"],
      scriptSrc: ["'self'", "'unsafe-inline'", "'unsafe-eval'", "https://cdnjs.cloudflare.com"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      imgSrc: ["'self'", "data:", "https:", "blob:"],
      connectSrc: ["'self'", "https:", "wss:"],
      fontSrc: ["'self'", "https:"],
      objectSrc: ["'none'"],
      mediaSrc: ["'self'", "blob:"],
      frameSrc: ["'none'"],
    },
  },
  crossOriginEmbedderPolicy: false,
  crossOriginResourcePolicy: { policy: 'cross-origin' },
}));

// Rate limiting — prevent brute force / abuse
const apiLimiter = new rateLimit({
  points: 100,           // 100 requests
  duration: 60,          // per minute per IP
});
const authLimiter = new rateLimit({
  points: 5,             // 5 auth attempts
  duration: 300,         // per 5 minutes
});
const aiLimiter = new rateLimit({
  points: 30,            // 30 AI requests
  duration: 60,          // per minute
});

// Anti-scrape: block known scrapers, bots, curl, wget
const blockedAgents = ['curl', 'wget', 'scrapy', 'python-requests', 'httpclient', 'okhttp', 'java/', 'go-http-client', 'bot', 'crawler', 'spider'];
app.use((req, res, next) => {
  const ua = (req.headers['user-agent'] || '').toLowerCase();
  for (const bot of blockedAgents) {
    if (ua.includes(bot) && !ua.includes('pwa')) {
      // Allow search engine bots but block scrapers
      if (ua.includes('googlebot') || ua.includes('bingbot')) { return next(); }
      return res.status(403).send('Access denied');
    }
  }
  next();
});

// Anti-hotlink: check referer for game assets
app.use('/game', (req, res, next) => {
  const referer = req.headers.referer || '';
  const host = req.headers.host || '';
  if (referer && !referer.includes(host) && !referer.includes('localhost') && !referer.includes('repl.co')) {
    return res.status(403).send('Hotlinking forbidden');
  }
  next();
});

// ==========================================
// RATE LIMITING
// ==========================================
app.use('/api/', async (req, res, next) => {
  try {
    await apiLimiter.consume(req.ip);
    next();
  } catch (e) {
    res.status(429).json({ error: 'Too many requests' });
  }
});

app.use('/api/auth/', async (req, res, next) => {
  try {
    await authLimiter.consume(req.ip);
    next();
  } catch (e) {
    res.status(429).json({ error: 'Too many auth attempts. Wait 5 minutes.' });
  }
});

app.use('/api/ai/', async (req, res, next) => {
  try {
    await aiLimiter.consume(req.ip);
    next();
  } catch (e) {
    res.status(429).json({ error: 'AI rate limit. Slow down.' });
  }
});

// ==========================================
// BODY PARSING
// ==========================================
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true, limit: '1mb' }));

// ==========================================
// INPUT SANITIZATION (anti-XSS, anti-injection)
// ==========================================
function sanitize(obj) {
  if (typeof obj === 'string') {
    return obj.replace(/<script[^>]*>.*?<\/script>/gi, '')
              .replace(/javascript:/gi, '')
              .replace(/on\w+\s*=/gi, '')
              .replace(/eval\(/gi, '')
              .replace(/[<>]/g, c => c === '<' ? '&lt;' : '&gt;')
              .substring(0, 5000);
  }
  if (typeof obj === 'object' && obj !== null) {
    for (const key in obj) {
      obj[key] = sanitize(obj[key]);
    }
  }
  return obj;
}

app.use('/api/', (req, res, next) => {
  req.body = sanitize(req.body);
  req.query = sanitize(req.query);
  next();
});

// ==========================================
// BALANCE INTEGRITY — anti-hack validation
// ==========================================
const balanceSignatures = new Map(); // In production use Redis
const SECRET_KEY = process.env.GAME_SECRET || crypto.randomBytes(32).toString('hex');

function signBalance(playerId, balance) {
  return crypto.createHmac('sha256', SECRET_KEY)
    .update(`${playerId}:${balance}:${Math.floor(Date.now() / 300000)}`)
    .digest('hex');
}

// ==========================================
// GAME ROUTES — serve static files
// ==========================================
// Serve ALL files from root (flat structure — everything at Replit root)
app.use(express.static(__dirname, {
  maxAge: '1h',
  setHeaders: (res, filepath) => {
    if (filepath.endsWith('.js')) res.setHeader('Content-Type', 'application/javascript');
    if (filepath.endsWith('.html')) res.setHeader('X-Frame-Options', 'DENY');
  }
}));

// Main route — serve index.html from root
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

// ==========================================
// PWA ROUTES
// ==========================================
app.get('/manifest.json', (req, res) => {
  res.json({
    name: 'OMEGA-8D',
    short_name: 'OMEGA-8D',
    description: '8D Tactical Arena Shooter — Real-world warfare across 12 eras',
    start_url: '/',
    display: 'standalone',
    orientation: 'any',
    background_color: '#0a0a0f',
    theme_color: '#00d4ff',
    icons: [
      { src: '/icon.svg', sizes: 'any', type: 'image/svg+xml', purpose: 'any maskable' },
      { src: '/icon-192.png', sizes: '192x192', type: 'image/png', purpose: 'any maskable' },
      { src: '/icon-512.png', sizes: '512x512', type: 'image/png', purpose: 'any maskable' },
    ],
    categories: ['games', 'action', 'strategy'],
    screenshots: [{ src: '/screenshot.png', sizes: '1280x720', type: 'image/png' }],
  });
});

app.get('/sw.js', (req, res) => {
  res.setHeader('Content-Type', 'application/javascript');
  res.send(`
    const CACHE = 'omega8d-v1';
    const ASSETS = ['/', '/manifest.json'];
    self.addEventListener('install', e => {
      e.waitUntil(caches.open(CACHE).then(c => c.addAll(ASSETS)));
      self.skipWaiting();
    });
    self.addEventListener('activate', e => { self.clients.claim(); });
    self.addEventListener('fetch', e => {
      if (e.request.method !== 'GET') return;
      e.respondWith(
        caches.match(e.request).then(r => r || fetch(e.request).then(resp => {
          if (resp.ok && e.request.url.includes('/game/')) {
            const clone = resp.clone();
            caches.open(CACHE).then(c => c.put(e.request, clone));
          }
          return resp;
        }).catch(() => caches.match('/')))
      );
    });
  `);
});

// Service worker registration injected into HTML
app.use((req, res, next) => {
  if (req.method === 'GET' && req.path === '/') {
    const oldSend = res.send;
    res.send = function(body) {
      if (typeof body === 'string' && body.includes('</head>')) {
        const pwaCode = `
          <link rel="manifest" href="/manifest.json">
          <meta name="theme-color" content="#00d4ff">
          <meta name="apple-mobile-web-app-capable" content="yes">
          <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
          <meta name="apple-mobile-web-app-title" content="OMEGA-8D">
          <meta name="mobile-web-app-capable" content="yes">
          <link rel="apple-touch-icon" href="/icon-192.png">
          <script>
            if ('serviceWorker' in navigator) {
              window.addEventListener('load', () => {
                navigator.serviceWorker.register('/sw.js').then(reg => {
                  console.log('PWA: ServiceWorker registered');
                }).catch(err => console.log('SW error:', err));
              });
            }
            let deferredPrompt;
            window.addEventListener('beforeinstallprompt', (e) => {
              e.preventDefault();
              deferredPrompt = e;
              const btn = document.createElement('button');
              btn.textContent = '📱 Install OMEGA-8D';
              btn.style.cssText = 'position:fixed;bottom:16px;left:50%;transform:translateX(-50%);z-index:9999;background:#00d4ff;color:#000;border:none;padding:14px 28px;border-radius:12px;font-weight:700;font-size:14px;cursor:pointer;box-shadow:0 4px 20px rgba(0,212,255,0.4)';
              btn.onclick = () => { deferredPrompt.prompt(); deferredPrompt.userChoice.then(() => { btn.remove(); }); };
              setTimeout(() => document.body.appendChild(btn), 3000);
            });
          </script>
        `;
        body = body.replace('</head>', pwaCode + '</head>');
      }
      oldSend.call(this, body);
    };
  }
  next();
});

// ==========================================
// AI PROXY — auto-routes to WhiteRabbit on :8081
// Zero config: the game calls /api/ai/ and it goes to llama.cpp automatically
// ==========================================
app.post('/api/ai/completion', async (req, res) => {
  try {
    const { prompt, messages, max_tokens, temperature } = req.body;
    
    // Build prompt from messages or direct prompt
    let fullPrompt = prompt;
    if (messages && Array.isArray(messages)) {
      fullPrompt = messages.map(m => `${m.role === 'user' ? 'User' : 'Assistant'}: ${m.content}`).join('\n');
    }

    const aiRes = await fetch(`http://127.0.0.1:${AI_PORT}/completion`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        prompt: fullPrompt,
        n_predict: max_tokens || 1000,
        temperature: temperature || 0.7,
        stop: ['User:', 'Assistant:'],
      }),
    });

    if (!aiRes.ok) {
      return res.status(502).json({ error: 'AI server unavailable', code: 'AI_DOWN' });
    }

    const aiData = await aiRes.json();
    res.json({
      success: true,
      response: aiData.content || aiData.completion || '',
      source: 'whiterabbit',
    });
  } catch (e) {
    res.status(502).json({ error: 'AI server offline', code: 'AI_OFFLINE' });
  }
});

// AI health check
app.get('/api/ai/health', async (req, res) => {
  try {
    const aiRes = await fetch(`http://127.0.0.1:${AI_PORT}/health`, { signal: AbortSignal.timeout(3000) });
    if (aiRes.ok) {
      res.json({ status: 'online', model: 'whiterabbit', source: 'local' });
    } else {
      res.status(503).json({ status: 'offline' });
    }
  } catch (e) {
    res.status(503).json({ status: 'offline', error: e.message });
  }
});

// AI config — tells the game where AI is (auto, no config needed)
app.get('/api/ai/config', (req, res) => {
  res.json({
    auto: true,
    endpoint: '/api/ai/completion',
    health: '/api/ai/health',
    model: 'whiterabbit',
    provider: 'local-llama-cpp',
    note: 'Zero config. AI is auto-wired to WhiteRabbit on this server.',
    userProvider: 'groq',
    userGetKeyUrl: 'https://console.groq.com/keys',
    userModels: {
      'llama-3.3-70b-versatile': { name: 'Llama 3.3 70B (Recommended)', tier: 'free' },
      'llama-3.1-8b-instant': { name: 'Llama 3.1 8B (Fastest)', tier: 'free' },
      'mixtral-8x7b-32768': { name: 'Mixtral 8x7B', tier: 'free' },
      'gemma2-9b-it': { name: 'Gemma 2 9B', tier: 'free' },
    },
  });
});

// ==========================================
// BALANCE SECURITY API — signed balances
// ==========================================
app.post('/api/balance/verify', (req, res) => {
  const { playerId, balance, signature } = req.body;
  const expectedSig = signBalance(playerId, balance);
  res.json({ valid: signature === expectedSig });
});

app.post('/api/balance/sign', (req, res) => {
  const { playerId, balance } = req.body;
  const signature = signBalance(playerId, balance);
  res.json({ signature });
});

// ==========================================
// ANTI-CHEAT: validate game actions
// ==========================================
const validActions = ['shoot', 'move', 'reload', 'ability', 'banish', 'warp', 'buy', 'equip', 'select'];
app.post('/api/game/action', async (req, res) => {
  const { action, playerId, data } = req.body;
  
  if (!validActions.includes(action)) {
    return res.status(400).json({ error: 'Invalid action', code: 'CHEAT_DETECTED' });
  }
  
  // Check for impossible values (damage > 1000, speed hacks, etc)
  if (data) {
    if (data.damage && data.damage > 1000) return res.status(400).json({ error: 'Impossible damage', code: 'CHEAT_DAMAGE' });
    if (data.speed && data.speed > 500) return res.status(400).json({ error: 'Speed hack', code: 'CHEAT_SPEED' });
    if (data.coins && data.coins < 0) return res.status(400).json({ error: 'Negative coins', code: 'CHEAT_COINS' });
  }
  
  res.json({ valid: true, action, timestamp: Date.now() });
});

// ==========================================
// HEALTH CHECK (for keep-alive)
// ==========================================
app.get('/icon.svg', (req, res) => {
  res.setHeader('Content-Type', 'image/svg+xml');
  res.sendFile(path.join(__dirname, 'icon.svg'));
});

app.get('/icon-192.png', (req, res) => {
  const f = path.join(__dirname, 'icon-192.png');
  if (fs.existsSync(f)) { res.setHeader('Content-Type', 'image/png'); res.sendFile(f); }
  else { res.redirect('/icon.svg'); }
});

app.get('/icon-512.png', (req, res) => {
  const f = path.join(__dirname, 'icon-512.png');
  if (fs.existsSync(f)) { res.setHeader('Content-Type', 'image/png'); res.sendFile(f); }
  else { res.redirect('/icon.svg'); }
});

app.get('/health', (req, res) => {
  res.json({
    status: 'online',
    game: true,
    ai: 'checking...',
    uptime: process.uptime(),
    timestamp: Date.now(),
  });
});

// ==========================================
// 404 HANDLER
// ==========================================
app.use((req, res) => {
  if (req.path.startsWith('/api/')) {
    res.status(404).json({ error: 'Endpoint not found' });
  } else {
    res.status(404).send('Not found');
  }
});

// ==========================================
// START
// ==========================================
app.listen(PORT, '0.0.0.0', () => {
  console.log(`[OMEGA-8D] Game server running on port ${PORT}`);
  console.log(`[OMEGA-8D] AI proxy -> http://127.0.0.1:${AI_PORT}`);
  console.log(`[OMEGA-8D] PWA enabled — installable on any device`);
  console.log(`[OMEGA-8D] Security: helmet + rate limit + anti-scrape + anti-cheat`);
  console.log(`[OMEGA-8D] AI auto-wired — zero config needed`);
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('[OMEGA-8D] Shutting down...');
  process.exit(0);
});