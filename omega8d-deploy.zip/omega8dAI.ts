// OMEGA-8D AI Backend
// Admin: C++ Llama (llama.cpp) on Replit as main game AI
// Users: Groq FREE TIER only — users add their own Groq API key
import { createClientFromRequest } from "npm:@base44/sdk@0.8.31";

const getField = (e: any, f: string) => e?.data?.[f] ?? e?.[f] ?? null;

async function createRecord(base44: any, entityName: string, fields: any) {
  const created = await base44.asServiceRole.entities[entityName].create({ data: {} });
  await base44.asServiceRole.entities[entityName].update(created.id, fields as any);
  return created;
}

async function getConfig(base44: any, key: string) {
  const configs = await base44.asServiceRole.entities.GameConfig.list();
  const config = configs.find((c: any) => getField(c, "key") === key);
  return config ? getField(config, "value") : null;
}

async function setConfig(base44: any, key: string, value: string, description: string) {
  const configs = await base44.asServiceRole.entities.GameConfig.list();
  const existing = configs.find((c: any) => getField(c, "key") === key);
  if (existing) {
    await base44.asServiceRole.entities.GameConfig.update(existing.id, { value, description, updatedBy: "admin" } as any);
  } else {
    await createRecord(base44, "GameConfig", { key, value, category: "ai", description, updatedBy: "admin" });
  }
}

const GROQ_MODELS: any = {
  "llama-3.3-70b-versatile": { name: "Llama 3.3 70B (Recommended)", ctx: 32768, tier: "free" },
  "llama-3.1-8b-instant": { name: "Llama 3.1 8B (Fastest)", ctx: 128000, tier: "free" },
  "mixtral-8x7b-32768": { name: "Mixtral 8x7B", ctx: 32768, tier: "free" },
  "gemma2-9b-it": { name: "Gemma 2 9B", ctx: 8192, tier: "free" },
};

const GROQ_ENDPOINT = "https://api.groq.com/openai/v1/chat/completions";
const LLAMA_CPP_DEFAULT_ENDPOINT = "http://localhost:8080/completion";
const LLAMA_CPP_DEFAULT_MODEL = "llama-cpp";

async function callLLM(base44: any, messages: any[], userApiKey?: string, playerId?: string) {
  let endpoint, model, apiKey;

  if (userApiKey) {
    endpoint = GROQ_ENDPOINT;
    model = await getConfig(base44, `ai_user_model_${playerId}`) || "llama-3.3-70b-versatile";
    apiKey = userApiKey;
  } else {
    endpoint = await getConfig(base44, "ai_llm_endpoint") || LLAMA_CPP_DEFAULT_ENDPOINT;
    model = await getConfig(base44, "ai_llm_model") || LLAMA_CPP_DEFAULT_MODEL;
    apiKey = await getConfig(base44, "ai_llm_api_key") || "";
  }

  if (!apiKey && !endpoint.includes("localhost") && !endpoint.includes("replit")) {
    return { success: false, error: "No AI configured. Admin: set up C++ Llama on Replit. Users: add your free Groq API key." };
  }

  try {
    const isLlamaCpp = endpoint.includes("localhost") || endpoint.includes("replit") || model === "llama-cpp";

    if (isLlamaCpp) {
      const prompt = messages.map(m => `${m.role === "user" ? "User" : "Assistant"}: ${m.content}`).join("\n");
      const res = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt, n_predict: 1000, temperature: 0.7, stop: ["User:", "Assistant:"] }),
      });
      if (!res.ok) {
        return { success: false, error: `Llama.cpp error (${res.status})` };
      }
      const data = await res.json();
      return { success: true, response: data.content || data.completion || "", source: "llama-cpp" };
    } else {
      const res = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json", "Authorization": `Bearer ${apiKey}` },
        body: JSON.stringify({ model, messages, temperature: 0.7, max_tokens: 1000 }),
      });
      if (!res.ok) {
        const errText = await res.text();
        return { success: false, error: `Groq API error (${res.status}): ${errText.substring(0, 200)}` };
      }
      const data = await res.json();
      return { success: true, response: data.choices?.[0]?.message?.content || "", source: "groq", usage: data.usage || null };
    }
  } catch (e) {
    return { success: false, error: `AI call failed: ${e.message}` };
  }
}

Deno.serve(async (req) => {
  const base44 = createClientFromRequest(req);
  const body = await req.json();
  const { action, data } = body;

  try {
    switch (action) {

      case "adminSetAIConfig": {
        const { endpoint, model, apiKey } = data;
        const results: any = {};
        if (endpoint) results.endpoint = await setConfig(base44, "ai_llm_endpoint", endpoint, "C++ Llama server endpoint on Replit");
        if (model) results.model = await setConfig(base44, "ai_llm_model", model, "LLM model name");
        if (apiKey) results.apiKey = await setConfig(base44, "ai_llm_api_key", apiKey, "LLM API key (if needed)");
        return Response.json({ success: true, message: "AI config updated! C++ Llama endpoint set.", updated: results });
      }

      case "adminGetAIConfig": {
        const endpoint = await getConfig(base44, "ai_llm_endpoint");
        const model = await getConfig(base44, "ai_llm_model");
        const hasKey = await getConfig(base44, "ai_llm_api_key");
        return Response.json({ success: true, config: {
          endpoint: endpoint || LLAMA_CPP_DEFAULT_ENDPOINT,
          model: model || LLAMA_CPP_DEFAULT_MODEL,
          apiKeySet: !!hasKey,
          type: "llama-cpp",
          note: "Admin uses C++ Llama (llama.cpp) on Replit. Users use Groq free tier.",
          groqModels: GROQ_MODELS,
        }});
      }

      case "setUserAIKey": {
        const { playerId, apiKey, model } = data;
        if (!apiKey || !apiKey.startsWith("gsk_")) {
          return Response.json({ success: false, error: "Invalid key. Only Groq free tier API keys are accepted (starts with gsk_). Get one at https://console.groq.com/keys" });
        }
        if (model && !GROQ_MODELS[model]) {
          return Response.json({ success: false, error: "Invalid model. Only Groq free tier models are supported.", availableModels: Object.keys(GROQ_MODELS) });
        }
        await setConfig(base44, `ai_user_key_${playerId}`, apiKey, `User ${playerId} Groq free tier API key`);
        if (model) await setConfig(base44, `ai_user_model_${playerId}`, model, `User ${playerId} Groq model`);
        return Response.json({ success: true, message: "Groq API key saved! AI features unlocked.", model: model || "llama-3.3-70b-versatile" });
      }

      case "getUserAIStatus": {
        const { playerId } = data;
        const hasKey = await getConfig(base44, `ai_user_key_${playerId}`);
        const model = await getConfig(base44, `ai_user_model_${playerId}`);
        return Response.json({ success: true, hasKey: !!hasKey, model: model || "llama-3.3-70b-versatile", provider: "groq", groqModels: GROQ_MODELS, getKeyUrl: "https://console.groq.com/keys" });
      }

      case "aiAutoplayDecision": {
        const { playerId, gameState, userApiKey } = data;
        const userKey = userApiKey || await getConfig(base44, `ai_user_key_${playerId}`);
        const systemPrompt = `You are the AI auto-play system for OMEGA-8D, an 8D tactical arena shooter. Analyze the game state and decide the best tactical action. Respond with ONLY a JSON object.\n\nGame state:\n${JSON.stringify(gameState).substring(0, 2000)}\n\nRespond with JSON:\n{"action":"move|shoot|reload|ability|banish|strike|heal|defend|scavenge|warp","target":"enemy id or null","direction":"north|south|east|west|up|down|ana|kata|void|cosmic or null","reasoning":"brief","urgency":"low|medium|high|critical"}`;
        const result = await callLLM(base44, [
          { role: "system", content: "You are a tactical AI for a military shooter game. Output only JSON." },
          { role: "user", content: systemPrompt }
        ], userKey, playerId);
        if (result.success) {
          try {
            const clean = result.response.replace(/```json|```/g, "").trim();
            const decision = JSON.parse(clean);
            return Response.json({ success: true, decision, raw: result.response, source: result.source });
          } catch (e) {
            return Response.json({ success: true, decision: { action: "defend", reasoning: "Parse error" }, raw: result.response, source: result.source });
          }
        }
        return Response.json(result);
      }

      case "updateAIBehavior": {
        const { playerId, stats } = data;
        const behaviors = await base44.asServiceRole.entities.AIBehavior.list();
        let behavior = behaviors.find((b: any) => getField(b, "playerId") === playerId);
        if (!behavior) {
          behavior = await createRecord(base44, "AIBehavior", {
            playerId, playstyle: stats.playstyle || "balanced", difficulty: stats.difficulty || "normal",
            subscriptionActive: false, subscriptionExpiry: "", aiKills: 0, aiDeaths: 0, aiWinRate: 0,
            cheatsUsed: 0, banishesPerformed: 0, survivalActivations: 0, strikesCalled: 0, totalAIPlaytime: 0, learnedPatterns: [],
          });
        }
        const updates: any = {};
        if (stats.aiKills !== undefined) updates.aiKills = (getField(behavior, "aiKills") || 0) + stats.aiKills;
        if (stats.aiDeaths !== undefined) updates.aiDeaths = (getField(behavior, "aiDeaths") || 0) + stats.aiDeaths;
        if (stats.cheatsUsed !== undefined) updates.cheatsUsed = (getField(behavior, "cheatsUsed") || 0) + stats.cheatsUsed;
        if (stats.banishesPerformed !== undefined) updates.banishesPerformed = (getField(behavior, "banishesPerformed") || 0) + stats.banishesPerformed;
        if (stats.playstyle) updates.playstyle = stats.playstyle;
        if (stats.difficulty) updates.difficulty = stats.difficulty;
        if (stats.learnedPattern) {
          const existing = getField(behavior, "learnedPatterns") || [];
          existing.push({ pattern: stats.learnedPattern, timestamp: new Date().toISOString() });
          if (existing.length > 100) existing.shift();
          updates.learnedPatterns = existing;
        }
        if (Object.keys(updates).length > 0) {
          await base44.asServiceRole.entities.AIBehavior.update(behavior.id, updates as any);
        }
        return Response.json({ success: true, message: "AI behavior updated", updates });
      }

      case "activateAISubscription": {
        const { playerId } = data;
        const wallets = await base44.asServiceRole.entities.WalletBalance.list();
        const wallet = wallets.find((w: any) => getField(w, "playerId") === playerId);
        if (!wallet) return Response.json({ success: false, error: "Wallet not found" });
        const balance = getField(wallet, "balanceUSD") || 0;
        if (balance < 300) return Response.json({ success: false, error: "AI auto-play costs $300/year. Balance: $" + balance });
        await base44.asServiceRole.entities.WalletBalance.update(wallet.id, { balanceUSD: balance - 300, totalSpent: (getField(wallet, "totalSpent") || 0) + 300 } as any);
        const behaviors = await base44.asServiceRole.entities.AIBehavior.list();
        let behavior = behaviors.find((b: any) => getField(b, "playerId") === playerId);
        const expiry = new Date(); expiry.setFullYear(expiry.getFullYear() + 1);
        if (behavior) {
          await base44.asServiceRole.entities.AIBehavior.update(behavior.id, { subscriptionActive: true, subscriptionExpiry: expiry.toISOString() } as any);
        } else {
          await createRecord(base44, "AIBehavior", { playerId, subscriptionActive: true, subscriptionExpiry: expiry.toISOString(), playstyle: "balanced", difficulty: "normal", aiKills: 0, aiDeaths: 0, aiWinRate: 0, cheatsUsed: 0, banishesPerformed: 0, survivalActivations: 0, strikesCalled: 0, totalAIPlaytime: 0, learnedPatterns: [] });
        }
        return Response.json({ success: true, message: "AI auto-play activated for 1 year!", expiry: expiry.toISOString(), cost: 300 });
      }

      case "checkDoomsdaySurvival": {
        const { playerId } = data;
        const behaviors = await base44.asServiceRole.entities.AIBehavior.list();
        const behavior = behaviors.find((b: any) => getField(b, "playerId") === playerId);
        if (!behavior) return Response.json({ success: false, error: "No AI behavior found" });
        const survivalCount = getField(behavior, "survivalActivations") || 0;
        const cheats = getField(behavior, "cheatsUsed") || 0;
        const survives = survivalCount > 0 || cheats > 5;
        return Response.json({ success: true, survives, survivalCount, cheatsUsed: cheats, message: survives ? "You have survival traits!" : "No survival traits — find a bunker!" });
      }

      case "loginDevice": {
        const { playerId, deviceName, deviceType } = data;
        const behaviors = await base44.asServiceRole.entities.AIBehavior.list();
        let behavior = behaviors.find((b: any) => getField(b, "playerId") === playerId);
        if (!behavior) {
          behavior = await createRecord(base44, "AIBehavior", { playerId, playstyle: "balanced", difficulty: "normal", subscriptionActive: false, subscriptionExpiry: "", aiKills: 0, aiDeaths: 0, aiWinRate: 0, cheatsUsed: 0, banishesPerformed: 0, survivalActivations: 0, strikesCalled: 0, totalAIPlaytime: 0, learnedPatterns: [] });
        }
        return Response.json({ success: true, playerId, device: deviceName, type: deviceType, message: `Logged in on ${deviceName} (${deviceType})` });
      }

      case "testLLM": {
        const result = await callLLM(base44, [
          { role: "system", content: "You are a game AI. Respond briefly." },
          { role: "user", content: "Say 'OMEGA-8D AI online' in exactly those words." }
        ]);
        return Response.json({ success: result.success, response: result.response, error: result.error, source: result.source || "unknown" });
      }

      case "processVoiceCommand": {
        const { playerId, command, gameState, userApiKey } = data;
        const userKey = userApiKey || await getConfig(base44, `ai_user_key_${playerId}`);
        const result = await callLLM(base44, [
          { role: "system", content: "You are OMEGA-8D's voice command processor. Convert natural language into JSON game actions. Output ONLY JSON." },
          { role: "user", content: `Command: "${command}"\nGame state: ${JSON.stringify(gameState || {}).substring(0, 500)}\nRespond: {"action":"...","params":{...}}` }
        ], userKey, playerId);
        if (result.success) {
          try {
            const clean = result.response.replace(/```json|```/g, "").trim();
            const parsed = JSON.parse(clean);
            return Response.json({ success: true, command: parsed, raw: result.response, source: result.source });
          } catch (e) {
            return Response.json({ success: true, command: { action: "unknown", params: {} }, raw: result.response });
          }
        }
        return Response.json(result);
      }

      case "getGroqInfo": {
        return Response.json({ success: true, provider: "groq", tier: "free", models: GROQ_MODELS, endpoint: GROQ_ENDPOINT, getKeyUrl: "https://console.groq.com/keys", note: "Users can only add Groq free tier API keys. Admin uses C++ Llama on Replit." });
      }

      default:
        return Response.json({ success: false, error: "Unknown action: " + action });
    }
  } catch (error) {
    return Response.json({ success: false, error: error.message });
  }
});