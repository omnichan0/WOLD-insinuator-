#!/bin/bash
# OMEGA-8D — ONE-CLICK REPLIT DEPLOY
# 
# HOW TO USE:
# 1. Upload omega8d.zip to Replit
# 2. In Replit shell: unzip omega8d.zip
# 3. Hit the green Run button
# 4. That's it. Game goes live.
#
# Everything auto-happens:
# - llama.cpp clones + builds
# - WhiteRabbit (3.8GB) downloads (first time, ~10 min)
# - AI server starts
# - Game server starts with security + PWA
# - Keep-alive daemon runs
# - Icons generate
# - Game is live on the internet

set -e

echo "=========================================="
echo "   OMEGA-8D — ONE-CLICK DEPLOY"
echo "=========================================="
echo ""

# ==========================================
# STEP 1: Generate PWA icons
# ==========================================
echo "[1/7] Generating PWA icons..."
bash gen_icons.sh 2>/dev/null || {
  cp icon.svg icon-512.png 2>/dev/null || true
  cp icon.svg icon-192.png 2>/dev/null || true
}

# ==========================================
# STEP 2: Install Node.js dependencies
# ==========================================
echo "[2/7] Installing server dependencies..."
npm install --silent 2>/dev/null || true

# ==========================================
# STEP 3: Clone + build llama.cpp (only if not built)
# ==========================================
if [ ! -f "llama.cpp/server" ]; then
  echo "[3/7] Cloning llama.cpp..."
  git clone https://github.com/ggerganov/llama.cpp --depth 1 2>/dev/null || true
  echo "[3/7] Building llama.cpp..."
  cd llama.cpp
  make -j$(nproc) server 2>&1 | tail -3
  cd ..
else
  echo "[3/7] llama.cpp already built"
fi

# ==========================================
# STEP 4: Download WhiteRabbit model (only if not downloaded)
# ==========================================
if [ ! -f "llama.cpp/whiterabbit.gguf" ]; then
  echo "[4/7] Downloading WhiteRabbit model (3.8GB)..."
  echo "This takes 5-15 min on first run..."
  cd llama.cpp
  
  # Try WhiteRabbit mirrors
  for url in \
    "https://huggingface.co/TheBloke/WhiteRabbit-II-7B-GGUF/resolve/main/whiterabbit-ii-7b.Q4_K_M.gguf" \
    "https://huggingface.co/TheBloke/WhiteRabbit-II-7B-GGUF/resolve/main/whiterabbit-ii-7b.Q3_K_M.gguf" \
    "https://huggingface.co/TheBloke/WhiteRabbitNeo-7B-v2-GGUF/resolve/main/whiterabbitneo-7b-v2.Q4_K_M.gguf"; do
    echo "  Trying: $(echo $url | sed 's|.*/||')"
    wget -q --show-progress -O whiterabbit.gguf "$url" 2>&1 || true
    SIZE=$(stat -c%s whiterabbit.gguf 2>/dev/null || stat -f%z whiterabbit.gguf 2>/dev/null || echo 0)
    if [ "$SIZE" -gt 1000000000 ]; then
      echo "  Downloaded: $((SIZE / 1024 / 1024)) MB ✓"
      break
    fi
    rm -f whiterabbit.gguf
  done
  
  # Fallback: Llama 3.1 8B
  SIZE=$(stat -c%s whiterabbit.gguf 2>/dev/null || stat -f%z whiterabbit.gguf 2>/dev/null || echo 0)
  if [ "$SIZE" -lt 1000000000 ]; then
    echo "  WhiteRabbit failed — downloading Llama 3.1 8B fallback..."
    wget -q --show-progress -O whiterabbit.gguf \
      "https://huggingface.co/QuantFactory/Meta-Llama-3.1-8B-Instruct-GGUF/resolve/main/Meta-Llama-3.1-8B-Instruct.Q4_K_M.gguf" || true
  fi
  cd ..
else
  echo "[4/7] WhiteRabbit model already downloaded"
fi

# ==========================================
# STEP 5: Start WhiteRabbit AI server (port 8081)
# ==========================================
echo "[5/7] Starting WhiteRabbit AI server..."
pkill -f "llama.*server" 2>/dev/null || true
sleep 1

cd llama.cpp
./server -m whiterabbit.gguf -c 4096 --host 127.0.0.1 --port 8081 -ngl 0 2>&1 &
AI_PID=$!
cd ..

# Wait for AI to load
echo "  Loading model (30-60s)..."
for i in $(seq 1 90); do
  if curl -s http://127.0.0.1:8081/health > /dev/null 2>&1; then
    echo "  AI server online ✓"
    break
  fi
  printf "."
  sleep 1
done
echo ""

# ==========================================
# STEP 6: Start game server (port 8080) + keep-alive daemon
# ==========================================
echo "[6/7] Starting game server (with self-heal) + daemon..."

# Self-heal wrapper: if node crashes, auto-restart within 3 seconds
nohup bash -c 'while true; do node server.js; echo "[Thu Aug 13 14:20:29 UTC 2026] Server crashed — SELF-HEAL restarting in 3s..."; sleep 3; done' > /dev/null 2>&1 &
GAME_PID=$!
echo "  Game server started with self-heal (auto-restart on crash) ✓"

sleep 2
nohup bash keepalive.sh > /dev/null 2>&1 &
echo "  Keep-alive + self-heal daemon started ✓"

# ==========================================
# STEP 7: Show status
# ==========================================
echo ""
echo "[7/7] Generating status..."
sleep 2

# Get public URL
REPL_URL="https://${REPL_SLUG:-your-repl}.${REPL_OWNER:-username}.repl.co"

# Check health
AI_STATUS="🔴 Loading..."
if curl -s http://127.0.0.1:8081/health > /dev/null 2>&1; then
  AI_STATUS="🟢 Online (WhiteRabbit)"
fi

GAME_STATUS="🔴 Starting..."
if curl -s http://localhost:8080/health > /dev/null 2>&1; then
  GAME_STATUS="🟢 Online"
fi

echo ""
echo "=========================================="
echo "   OMEGA-8D IS LIVE!"
echo "=========================================="
echo ""
echo "  Game: $GAME_STATUS"
echo "  AI:   $AI_STATUS"
echo "  URL:  $REPL_URL"
echo ""
echo "  Anyone on the internet can:"
echo "  1. Visit $REPL_URL to play"
echo "  2. Install as PWA on their device"
echo "  3. Use AI (WhiteRabbit, auto-wired)"
echo "  4. Add their own Groq key for personal AI"
echo ""
echo "  Security: anti-hack, anti-scrape, rate-limited"
echo "  Daemon: keep-alive running (pings every 10 min)"
echo "  PWA: installable on any device"
echo "=========================================="
echo ""
echo "Press Ctrl+C to stop."

# Keep alive
wait $GAME_PID