# OMEGA-8D AI Setup Guide

## Admin: C++ Llama on Replit

The game AI runs on your Replit with C++ Llama (llama.cpp). This is the shared game AI.

### Setup on Replit:

1. Create a new Repl (Python or Bash template)
2. Install llama.cpp:
```bash
git clone https://github.com/ggerganov/llama.cpp
cd llama.cpp
make
```

3. Download a model (recommended: Llama 3.1 8B):
```bash
wget https://huggingface.co/QuantFactory/Meta-Llama-3.1-8B-Instruct-GGUF/resolve/main/Meta-Llama-3.1-8B-Instruct.Q4_K_M.gguf
```

4. Start the server:
```bash
./server -m Meta-Llama-3.1-8B-Instruct.Q4_K_M.gguf -c 4096 --port 8080 --host 0.0.0.0
```

5. Copy your Replit URL (looks like: `https://your-repl-name.username.repl.co`)

6. In OMEGA-8D admin panel:
   - Go to AI Config tab
   - Paste your Replit URL + `/completion` as endpoint
   - Set model to `llama-cpp`
   - Save

The game will now use your C++ Llama for all AI features: auto-play, voice commands, tactical decisions, cognitive warfare.

## Users: Groq Free Tier API Key

Players can add their OWN Groq free tier API key for personal AI features.

### How players get a key:

1. Go to https://console.groq.com/keys
2. Create a free account
3. Generate an API key (starts with `gsk_`)
4. In OMEGA-8D, open Wallet panel → AI Settings tab
5. Paste the Groq key
6. Select a model:
   - Llama 3.3 70B (Recommended) — best quality
   - Llama 3.1 8B (Fastest) — lowest latency
   - Mixtral 8x7B — balanced
   - Gemma 2 9B — lightweight

### Why Groq free tier:
- Free (no cost)
- No content flagging (won't block game content)
- Fast inference (Groq runs on LPUs)
- Users bring their own key = no shared cost

### How it works in game:
- If user has Groq key: their key is used for their AI features
- If no user key: admin's C++ Llama on Replit is used
- If neither: AI features show "set up AI" message