# Theme Reference

```css
:root {
  --bg-primary: #000000; /* transparent on additive display — real world shows through */
  --bg-secondary: #0a0a0f;
  --bg-tertiary: #14141f;
  --bg-card: #1a1a2e;
  --text-primary: #ffffff;
  --text-secondary: #a0a0b0;
  --text-muted: #606070;
  --accent-primary: #00d4ff;
  --accent-secondary: #00ff88;
  --accent-warm: #ff9f43;
  --danger: #ff4466;
  --focus-ring: #00d4ff;
  --focus-glow: rgba(0, 212, 255, 0.4);
  --success: #00ff88;
  --warning: #ffaa00;
  --info: #00b4d8;
  --radius-sm: 8px;
  --radius-md: 12px;
  --radius-lg: 16px;
}

* { margin: 0; padding: 0; box-sizing: border-box; }

body {
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
  background: var(--bg-primary);
  color: var(--text-primary);
  width: 600px;
  height: 600px;
  overflow: hidden;
}

#app { width: 100%; height: 100%; position: relative; }

/* --- Screens --- */
.screen {
  width: 100%; height: 100%;
  display: flex; flex-direction: column;
  position: absolute; top: 0; left: 0;
}
.screen.hidden { display: none; }

/* --- Header --- */
.header {
  display: flex; align-items: center; gap: 12px;
  padding: 16px 20px;
  background: var(--bg-secondary);
  flex-shrink: 0;
}
.header h1 { font-size: 22px; font-weight: 600; flex: 1; }
.header-meta { font-size: 13px; color: var(--text-secondary); }
.back-btn {
  background: transparent; color: var(--text-primary);
  font-size: 22px; padding: 8px 12px;
  border-radius: var(--radius-sm); border: 2px solid transparent;
}

/* --- Content --- */
.content {
  flex: 1; padding: 16px 20px; overflow-y: auto;
  display: flex; flex-direction: column; gap: 12px;
}

/* --- Focus states (critical for D-pad input) --- */
.focusable {
  border: 2px solid transparent;
  cursor: pointer; min-height: 44px;
}
.focusable:focus {
  outline: none;
  border-color: var(--focus-ring);
  box-shadow: 0 0 20px var(--focus-glow);
}

/* --- Nav bar --- */
.nav-bar {
  display: flex; gap: 8px; padding: 12px 20px;
  background: var(--bg-secondary); flex-shrink: 0;
}
.nav-item {
  flex: 1; padding: 14px 16px;
  background: var(--bg-tertiary); border-radius: var(--radius-md);
  color: var(--text-primary); font-size: 15px; font-weight: 500;
  text-align: center;
  display: flex; align-items: center; justify-content: center; gap: 8px;
}
.nav-item:focus { background: var(--bg-card); }
.nav-item.primary { background: var(--accent-primary); color: #0a0a0f; }
.nav-item.primary:focus { background: #33ddff; }
.nav-item.danger { background: var(--danger); color: white; }

/* --- Cards --- */
.card {
  background: var(--bg-card); border-radius: var(--radius-md);
  padding: 16px; border: 2px solid transparent;
}
.card:focus { border-color: var(--focus-ring); box-shadow: 0 0 20px var(--focus-glow); }
.card-title { font-size: 18px; font-weight: 600; margin-bottom: 6px; }
.card-subtitle { font-size: 14px; color: var(--text-secondary); }
.card-value { font-size: 28px; font-weight: 700; color: var(--accent-primary); }

/* --- List items --- */
.list-container {
  display: flex; flex-direction: column; gap: 8px;
  overflow-y: auto; max-height: 400px;
}
.list-item {
  display: flex; align-items: center; gap: 12px;
  padding: 14px 16px;
  background: var(--bg-tertiary); border-radius: var(--radius-md);
  color: var(--text-primary); font-size: 15px; text-align: left;
}
.list-item:focus { background: var(--bg-card); }
.list-item-icon { font-size: 24px; flex-shrink: 0; width: 36px; text-align: center; }
.list-item-content { flex: 1; min-width: 0; }
.list-item-title { font-weight: 500; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.list-item-meta { font-size: 13px; color: var(--text-secondary); margin-top: 2px; }

/* --- Loading --- */
.loading-container {
  display: flex; flex-direction: column; align-items: center; justify-content: center;
  gap: 16px; padding: 40px; flex: 1;
}
.loading-spinner {
  width: 48px; height: 48px;
  border: 4px solid var(--bg-tertiary); border-top-color: var(--accent-primary);
  border-radius: 50%;
}
.loading-text { font-size: 16px; color: var(--text-secondary); }

/* --- Error --- */
.error-container {
  display: flex; flex-direction: column; align-items: center; justify-content: center;
  gap: 12px; padding: 40px; text-align: center;
}
.error-icon { font-size: 48px; }
.error-message { font-size: 16px; color: var(--text-secondary); max-width: 400px; }

/* --- Toast --- */
.toast {
  position: fixed; bottom: 80px; left: 50%;
  transform: translateX(-50%) translateY(100px);
  background: var(--bg-card); color: var(--text-primary);
  padding: 12px 24px; border-radius: var(--radius-md);
  font-size: 14px; border: 1px solid var(--accent-primary);
  transition: transform 0.3s ease; z-index: 100; pointer-events: none;
}
.toast.visible { transform: translateX(-50%) translateY(0); }
.toast.error { border-color: var(--danger); }
.toast.success { border-color: var(--success); }

/* --- Badges --- */
.badge { display: inline-block; padding: 4px 10px; border-radius: 20px; font-size: 12px; font-weight: 600; }
.badge-success { background: rgba(0, 255, 136, 0.2); color: var(--success); }
.badge-warning { background: rgba(255, 170, 0, 0.2); color: var(--warning); }
.badge-danger { background: rgba(255, 68, 102, 0.2); color: var(--danger); }
.badge-info { background: rgba(0, 180, 216, 0.2); color: var(--info); }

/* --- Data grid --- */
.data-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }

/* --- Text input --- */
.text-input {
  width: 100%; padding: 14px 16px; font-size: 16px;
  background: var(--bg-tertiary); color: var(--text-primary);
  border-radius: var(--radius-md); border: 2px solid transparent;
}
.text-input:focus { border-color: var(--focus-ring); box-shadow: 0 0 20px var(--focus-glow); outline: none; }
.text-input::placeholder { color: var(--text-muted); }

/* --- Utility --- */
.hidden { display: none !important; }
.text-center { text-align: center; }
.text-accent { color: var(--accent-primary); }
.text-muted { color: var(--text-secondary); }
```
