---
name: filesystem-and-git-cleanup
description: Clean up Git and LFS bloat and oversized files that checkpoints skip, so the project tracks only what it needs.
---

# Filesystem and Git cleanup

Goal: leave the project's files and Git in a better state. Git should track source and the assets the app needs, nothing else; over time, a large Git and LFS history makes Git operations grind to a halt. Checkpoints skip new files at or above the size limit, so those files are unprotected until you resolve them. Resolve them now; don't leave them for a later turn.

For each large or unneeded path, choose based on why it exists:
- **Not needed** (caches, build output, stray copies): delete it. Ask first if the user made it or it can't be regenerated.
- **Needed locally, not in Git:** add it to `.gitignore` and `.replitignore` and untrack it, once the user agrees. Rollback doesn't restore ignored files, which is why you ask.
- **Used by the app:** move it to App Storage and update the code that references it.
- **Must stay in Git:** use LFS as a last resort for large files or git directly otherwise, tracking only specific files, and commit it yourself, because checkpoints still skip it.
- **LFS bloat:** LFS keeps a full local copy of every version, so when it grows, prune old copies that are no longer needed. Prune only objects verified on the remote (`--verify-remote`); otherwise ask the user, since pruning can delete the last copy of an old version.

Don't move files into `.local/` or other hidden folders unless the user asks. If the user declines every option, tell them the files stay unprotected and suggest the best alternative.

The goal is removing bloat, not work: never rewrite history, force-push, or run a broad `git clean`. Confirm the next checkpoint succeeds.
