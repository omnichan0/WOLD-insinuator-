# Record a browser test

Use this guide when the testing skill directs you here for a requested video of a Browserbase test. The testing subagent collects screenshot evidence; the code or conversation parent exports it.

If you are a task agent or testing subagent, collect and report the test result and screenshot evidence to your parent. Do not call the export function, promise a video, or follow the export and presentation steps below.

The callback below is available to code and conversation parents when recording clips are enabled. Reading this shared file does not enable it. If the callback is unavailable, retain the screenshots and report that video export is unavailable.

## Request the evidence

Include the test URL, the interaction to show, and the visible result to wait for. Ask the tester to return:

- A screenshot ID showing the state immediately before the interaction.
- A screenshot ID showing its visible result, from the same page and browser context.
- The test verdict and a short description of what each screenshot shows.

Reuse a suitable pair from an existing report instead of repeating the test. Use the actual screenshot IDs in the report, not file paths or invented IDs. The interval must be ordered and no longer than two minutes. Local-browser screenshots cannot produce a Browserbase recording.

## Export and present

These steps are for the code or conversation parent with export access.

Wait until the tester has finished the requested browser work. Export ends the entire Browserbase session, including other tabs; it may also end the session if export fails.

Call `exportBrowserRecordingClip({ startScreenshotId, endScreenshotId })` once in CodeExecution using the selected IDs. You do not need to obtain session IDs or timestamps from the tester: the callback looks up the saved capture metadata.

Keep the returned `filePath` and `durationSeconds`. The MP4 is a local file in your current environment, not a published URL. Present that file once using your asset-presentation instructions. The clip may include extra footage around the selected screenshots.

If export fails, report the failure and keep the test result and screenshots. Do not automatically retry, repeat the test just to recreate a video, or switch recording methods. If presentation fails after export succeeded, keep the existing MP4 and fix presentation without exporting again.

## Continue testing afterward

Before further testing, tell the tester whether export succeeded or failed and that the session may have ended. If the old session is no longer usable, it should attempt cleanup once, report any cleanup error, then create a fresh context and repeat the required setup. A cleanup failure does not invalidate a completed test or an exported MP4.
